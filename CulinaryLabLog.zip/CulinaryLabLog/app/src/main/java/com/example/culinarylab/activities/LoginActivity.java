package com.example.culinarylab.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.models.User;
import com.example.culinarylab.R;

public class LoginActivity extends AppCompatActivity {

    EditText etUsername, etPassword;
    Button btnLogin;
    TextView tvRegister;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DBHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegisterLink);

        btnLogin.setOnClickListener(v -> {
            try {
                String user = etUsername.getText().toString().trim();
                String pass = etPassword.getText().toString().trim();

                if (user.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(this, "Masukkan username & password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                User u = db.authenticateUser(user, pass);

                if (u != null) {
                    Toast.makeText(this, "Login berhasil sebagai " + u.getRole(), Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(LoginActivity.this, DashboardActivity.class);
                    i.putExtra("userId", u.getId());
                    i.putExtra("role", u.getRole());
                    i.putExtra("username", u.getName());

                    startActivity(i);
                    // finish(); // Keep Login open for debugging if Dashboard crashes
                } else {
                    Toast.makeText(this, "Username atau password salah!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "LOGIN ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        tvRegister.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, RegisterActivity.class)));
    }
}
