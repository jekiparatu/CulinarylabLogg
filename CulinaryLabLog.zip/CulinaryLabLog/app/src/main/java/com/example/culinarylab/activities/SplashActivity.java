package com.example.culinarylab.activities;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.culinarylab.R;
import com.google.android.material.progressindicator.CircularProgressIndicator;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DURATION = 3000; // 3 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Get views
        ImageView ivLogo = findViewById(R.id.ivSplashLogo);
        TextView tvAppName = findViewById(R.id.tvAppName);
        TextView tvTagline = findViewById(R.id.tvTagline);
        CircularProgressIndicator progressIndicator = findViewById(R.id.progressIndicator);

        // Animate logo scale with bounce and rotation
        ivLogo.setScaleX(0f);
        ivLogo.setScaleY(0f);
        ivLogo.setRotation(-180f);
        ivLogo.animate()
                .scaleX(1f)
                .scaleY(1f)
                .rotation(0f)
                .setDuration(1000)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        // Add subtle bounce effect
                        ivLogo.animate()
                                .scaleX(1.1f)
                                .scaleY(1.1f)
                                .setDuration(200)
                                .setListener(new AnimatorListenerAdapter() {
                                    @Override
                                    public void onAnimationEnd(Animator animation) {
                                        ivLogo.animate()
                                                .scaleX(1f)
                                                .scaleY(1f)
                                                .setDuration(200)
                                                .start();
                                    }
                                })
                                .start();

                        // Animate app name
                        tvAppName.animate()
                                .alpha(1f)
                                .translationY(0f)
                                .setDuration(600)
                                .setStartDelay(100)
                                .start();

                        // Animate tagline
                        tvTagline.animate()
                                .alpha(1f)
                                .translationY(0f)
                                .setDuration(600)
                                .setStartDelay(300)
                                .start();

                        // Animate progress indicator
                        progressIndicator.animate()
                                .alpha(1f)
                                .setDuration(600)
                                .setStartDelay(500)
                                .start();
                    }
                })
                .start();

        // Navigate to Login after delay
        new Handler().postDelayed(() -> {
            try {
                Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                // Add transition animation
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            } catch (Exception e) {
                e.printStackTrace();
                // Force restart if splash fails
                Intent i = getBaseContext().getPackageManager()
                        .getLaunchIntentForPackage(getBaseContext().getPackageName());
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                }
            }
        }, SPLASH_DURATION);
    }
}
