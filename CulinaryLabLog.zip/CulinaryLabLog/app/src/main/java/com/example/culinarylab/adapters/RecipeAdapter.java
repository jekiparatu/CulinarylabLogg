package com.example.culinarylab.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.culinarylab.R;
import com.example.culinarylab.models.Recipe;

import java.util.ArrayList;
import java.util.List;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(Recipe r);
    }

    private List<Recipe> list;
    private final OnItemClickListener listener;

    public RecipeAdapter(List<Recipe> list, OnItemClickListener listener) {
        this.list = (list != null) ? list : new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public RecipeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_recipe, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecipeAdapter.ViewHolder holder, int position) {
        Recipe r = list.get(position);

        holder.tvTitle.setText(r.getTitle());
        holder.tvTitle.setText(r.getTitle());

        // Show Chef Name if available
        if (r.getChefName() != null && !r.getChefName().isEmpty()) {
            holder.tvChef.setText("Chef " + r.getChefName());
        } else {
            holder.tvChef.setText("Chef " + (r.getChefId() != 0 ? r.getChefId() : "-"));
        }

        // Rating
        if (r.getRating() > 0) {
            holder.tvRating.setText(String.valueOf(r.getRating()));
        } else {
            holder.tvRating.setText("-");
        }

        // Category
        if (r.getCategoryName() != null && !r.getCategoryName().isEmpty()) {
            holder.tvCategory.setText(r.getCategoryName());
            holder.tvCategory.setVisibility(View.VISIBLE);
        } else {
            holder.tvCategory.setVisibility(View.GONE);
        }

        // Regional
        if (r.getRegionalName() != null && !r.getRegionalName().isEmpty()) {
            holder.tvRegional.setText(r.getRegionalName());
        } else {
            holder.tvRegional.setText("Umum");
        }

        // Image Handling
        String imageUri = r.getImageUri();
        if (imageUri != null && !imageUri.isEmpty()) {
            // Check if resource or uri
            if (!imageUri.contains("/") && !imageUri.contains(":")) {
                int resId = holder.itemView.getContext().getResources().getIdentifier(imageUri, "drawable",
                        holder.itemView.getContext().getPackageName());
                if (resId != 0) {
                    holder.ivImage.setImageResource(resId);
                } else {
                    holder.ivImage.setImageResource(R.drawable.placeholder_recipe);
                }
            } else {
                try {
                    holder.ivImage.setImageURI(android.net.Uri.parse(imageUri));
                } catch (Exception e) {
                    holder.ivImage.setImageResource(R.drawable.placeholder_recipe);
                }
            }
        } else {
            holder.ivImage.setImageResource(R.drawable.placeholder_recipe);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null)
                listener.onItemClick(r);
        });
    }

    @Override
    public int getItemCount() {
        return (list != null) ? list.size() : 0;
    }

    public void setData(List<Recipe> newData) {
        this.list = (newData != null) ? newData : new ArrayList<>();
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvRating, tvChef, tvCategory, tvRegional;
        ImageView ivImage;

        ViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvRating = itemView.findViewById(R.id.tvRating);
            tvChef = itemView.findViewById(R.id.tvChefName);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvRegional = itemView.findViewById(R.id.tvRegional);
            ivImage = itemView.findViewById(R.id.ivRecipeImage);
        }
    }
}
