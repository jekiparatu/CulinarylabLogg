package com.example.culinarylab.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;
import com.example.culinarylab.activities.LoginActivity;
import com.example.culinarylab.activities.RecipeListActivity;
import com.example.culinarylab.models.Recipe;
import com.example.culinarylab.models.User;
import com.google.android.material.chip.Chip;

import java.util.List;
import android.content.res.ColorStateList;

public class ProfileFragment extends Fragment {

    TextView tvName, tvEmail, tvUsername, tvRoleDetail, tvRecipeCount;
    Chip tvRole;
    TextView btnEdit, btnPassword, btnHelp, btnLogout;
    LinearLayout btnMyRecipes;
    ImageView ivProfilePhoto;

    DBHelper db;
    String username;
    String role;
    int userId;

    private static final int REQUEST_EDIT_PROFILE = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        db = new DBHelper(getActivity());

        // Bind Views
        ivProfilePhoto = view.findViewById(R.id.ivProfilePhoto);
        tvName = view.findViewById(R.id.tvProfileName);
        tvRole = view.findViewById(R.id.tvProfileRole);
        tvEmail = view.findViewById(R.id.tvProfileEmail);
        tvUsername = view.findViewById(R.id.tvProfileUsername);
        tvRoleDetail = view.findViewById(R.id.tvProfileRoleDetail);
        tvRecipeCount = view.findViewById(R.id.tvRecipeCount);

        btnEdit = view.findViewById(R.id.btnEditProfile);
        btnPassword = view.findViewById(R.id.btnChangePassword);
        btnHelp = view.findViewById(R.id.btnHelp);
        btnLogout = view.findViewById(R.id.btnLogout);
        btnMyRecipes = view.findViewById(R.id.btnMyRecipes);

        // Get Data from Arguments (passed from DashboardActivity)
        if (getArguments() != null) {
            username = getArguments().getString("username");
            role = getArguments().getString("role");
            userId = getArguments().getInt("userId", -1);
        }

        // Fallback defaults
        if (username == null)
            username = "User";
        if (role == null)
            role = "guest";

        setupUI(view);
        setupListeners();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        updateStats();
    }

    private void setupUI(View view) {
        // Apply role-based gradient background
        LinearLayout profileHeader = view.findViewById(R.id.profileHeader);
        int gradientResource = R.drawable.gradient_background; // default
        int chipBackgroundColor = 0x80FFFFFF; // default semi-transparent white

        if (role != null) {
            switch (role.toLowerCase()) {
                case "admin":
                    gradientResource = R.drawable.gradient_admin;
                    chipBackgroundColor = getResources().getColor(R.color.admin_light);
                    break;
                case "chef":
                    gradientResource = R.drawable.gradient_chef;
                    chipBackgroundColor = getResources().getColor(R.color.chef_light);
                    break;
                case "reviewer":
                    gradientResource = R.drawable.gradient_reviewer;
                    chipBackgroundColor = getResources().getColor(R.color.reviewer_light);
                    break;
            }
        }

        if (profileHeader != null) {
            profileHeader.setBackgroundResource(gradientResource);
        }

        // Update role chip color
        if (tvRole != null) {
            int colorRes = role != null && role.equalsIgnoreCase("admin") ? R.color.admin_light
                    : role != null && role.equalsIgnoreCase("chef") ? R.color.chef_light
                            : role != null && role.equalsIgnoreCase("reviewer") ? R.color.reviewer_light
                                    : android.R.color.white;
            tvRole.setChipBackgroundColor(ColorStateList.valueOf(getResources().getColor(colorRes)));
        }

        // Load user data from database
        User user = db.getUserById(userId);
        if (user != null) {
            tvName.setText(user.getName());
            tvRole.setText(user.getRole().toUpperCase());
            tvUsername.setText(user.getName());
            tvRoleDetail.setText(user.getRole());

            // Display real email or generated one
            String email = user.getEmail();
            if (email == null || email.isEmpty()) {
                email = user.getName().toLowerCase().replace(" ", "") + "@culinarylab.com";
            }
            tvEmail.setText(email);

            // Load profile photo
            if (user.getPhotoUri() != null && !user.getPhotoUri().isEmpty()) {
                ivProfilePhoto.setImageURI(android.net.Uri.parse(user.getPhotoUri()));
            }
        } else {
            // Fallback to passed data
            tvName.setText(username);
            tvRole.setText(role.toUpperCase());
            tvUsername.setText(username);
            tvRoleDetail.setText(role);
            tvEmail.setText(username.toLowerCase().replace(" ", "") + "@culinarylab.com");
        }
    }

    private void updateStats() {
        try {
            List<Recipe> allRecipes = db.getAllRecipes();
            int count = 0;
            if (allRecipes != null) {
                // Filter by chefName/author...
                // Wait, Recipe model has chefId? Yes.
                // Wait, we need to know my chefId.
                // If I am just a 'user', maybe I don't have recipes?
                // The prompt assumes users can have recipes.
                // Checking Recipe model: `chefId` is int.
                // Our `userId` is int.

                for (Recipe r : allRecipes) {
                    if (r.getChefId() == userId) {
                        count++;
                    }
                }
            }
            tvRecipeCount.setText(count + " Resep");

        } catch (Exception e) {
            e.printStackTrace();
            tvRecipeCount.setText("0 Resep");
        }
    }

    private void setupListeners() {
        // Edit Photo
        ivProfilePhoto.setOnClickListener(v -> {
            Intent i = new Intent(getActivity(), com.example.culinarylab.activities.EditProfileActivity.class);
            i.putExtra("userId", userId);
            startActivityForResult(i, REQUEST_EDIT_PROFILE);
        });

        btnLogout.setOnClickListener(v -> {
            // Logout
            Intent i = new Intent(getActivity(), LoginActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            getActivity().finish();
        });

        btnMyRecipes.setOnClickListener(v -> {
            // Navigate to RecipeListActivity filtered by user's recipes
            Intent i = new Intent(getActivity(), RecipeListActivity.class);
            i.putExtra("userId", userId);
            i.putExtra("role", role);
            i.putExtra("filterByUser", true);
            startActivity(i);
        });

        btnEdit.setOnClickListener(v -> {
            Intent i = new Intent(getActivity(), com.example.culinarylab.activities.EditProfileActivity.class);
            i.putExtra("userId", userId);
            startActivityForResult(i, REQUEST_EDIT_PROFILE);
        });

        btnPassword.setOnClickListener(v -> {
            Intent i = new Intent(getActivity(), com.example.culinarylab.activities.ChangePasswordActivity.class);
            i.putExtra("userId", userId);
            startActivity(i);
        });

        btnHelp.setOnClickListener(v -> {
            Intent i = new Intent(getActivity(), com.example.culinarylab.activities.HelpActivity.class);
            startActivity(i);
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EDIT_PROFILE && resultCode == getActivity().RESULT_OK) {
            // Refresh profile data
            if (getView() != null) {
                setupUI(getView());
            }
            updateStats();
        }
    }
}
