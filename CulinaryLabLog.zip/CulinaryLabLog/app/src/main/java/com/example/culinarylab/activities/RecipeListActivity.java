package com.example.culinarylab.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;
import com.example.culinarylab.adapters.RecipeAdapter;
import com.example.culinarylab.models.Recipe;

import java.util.ArrayList;
import java.util.List;

public class RecipeListActivity extends AppCompatActivity implements RecipeAdapter.OnItemClickListener {

    RecyclerView rv;
    androidx.appcompat.widget.SearchView searchView;
    android.widget.TextView tvEmpty;
    RecipeAdapter adapter;
    DBHelper db;
    int userId = -1;
    String role = "";

    // Filters
    String categoryFilter = null;
    boolean filterByUser = false;
    boolean showFavorites = false; // New: Favorites
    int chefIdFilter = -1; // New: Chef
    String chefNameFilter = null; // New: Chef Name

    List<Recipe> recipeList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            setContentView(R.layout.activity_recipe_list);

            db = new DBHelper(this);

            rv = findViewById(R.id.rvRecipes);
            searchView = findViewById(R.id.searchView);
            tvEmpty = findViewById(R.id.tvEmptyState);

            if (rv == null) {
                throw new RuntimeException("RecyclerView tidak ditemukan.");
            }

            rv.setLayoutManager(new LinearLayoutManager(this));

            // Ambil data kiriman
            userId = getIntent().getIntExtra("userId", -1);
            role = getIntent().getStringExtra("role");
            categoryFilter = getIntent().getStringExtra("category");
            filterByUser = getIntent().getBooleanExtra("filterByUser", false);
            showFavorites = getIntent().getBooleanExtra("showFavorites", false);
            chefIdFilter = getIntent().getIntExtra("chefIdFilter", -1);
            chefNameFilter = getIntent().getStringExtra("chefNameFilter");

            Log.d("RecipeList", "Received - userId: " + userId + ", role: " + role + ", category: " + categoryFilter
                    + ", filterByUser: " + filterByUser + ", favorites: " + showFavorites + ", chefId: "
                    + chefIdFilter);

            // Provide defaults if missing
            if (role == null || role.isEmpty())
                role = "guest";
            if (userId == -1)
                userId = 0;

            // Update title based on filter
            if (showFavorites) {
                setTitle("Resep Favorit Saya");
            } else if (filterByUser) {
                setTitle("Resep Saya");
            } else if (chefIdFilter != -1) {
                setTitle("Resep oleh " + (chefNameFilter != null ? chefNameFilter : "Chef"));
            } else if (categoryFilter != null && !categoryFilter.isEmpty()) {
                setTitle("Kategori: " + categoryFilter);
            } else {
                setTitle("Daftar Resep");
            }

            adapter = new RecipeAdapter(recipeList, this);
            rv.setAdapter(adapter);

            loadList();

            // Search Listeners
            if (searchView != null) {
                searchView.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        performSearch(query);
                        return true;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        if (newText.isEmpty()) {
                            loadList(); // Reset if empty
                        } else {
                            performSearch(newText); // Real-time search
                        }
                        return true;
                    }
                });
            }

        } catch (Exception e) {
            Toast.makeText(this, "ERROR DI DAFTAR RESEP: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
            finish();
        }
    }

    private void performSearch(String query) {
        List<Recipe> results = db.getRecipesBySearch(query);
        updateList(results);
    }

    private void loadList() {
        List<Recipe> newList;

        if (showFavorites) {
            newList = db.getFavoriteRecipes(userId);
        } else if (filterByUser) {
            newList = db.getRecipesByChef(userId);
        } else if (chefIdFilter != -1) {
            newList = db.getRecipesByChef(chefIdFilter);
        } else if (categoryFilter != null && !categoryFilter.isEmpty()) {
            newList = db.getRecipesByCategory(categoryFilter);
        } else {
            newList = db.getAllRecipes();
        }

        updateList(newList);
    }

    private void updateList(List<Recipe> list) {
        if (list == null)
            list = new ArrayList<>();

        recipeList.clear();
        recipeList.addAll(list);

        if (adapter != null)
            adapter.notifyDataSetChanged();

        if (recipeList.isEmpty()) {
            rv.setVisibility(android.view.View.GONE);
            if (tvEmpty != null) {
                tvEmpty.setVisibility(android.view.View.VISIBLE);
                if (showFavorites)
                    tvEmpty.setText("Belum ada resep favorit.");
                else
                    tvEmpty.setText("Tidak ada resep ditemukan.");
            }
        } else {
            rv.setVisibility(android.view.View.VISIBLE);
            if (tvEmpty != null)
                tvEmpty.setVisibility(android.view.View.GONE);
        }
    }

    @Override
    public void onItemClick(Recipe r) {
        if (r == null)
            return;

        Intent i = new Intent(this, RecipeDetailActivity.class);
        i.putExtra("recipeId", r.getId());
        i.putExtra("userId", userId);
        i.putExtra("role", role);
        startActivity(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (searchView != null && searchView.getQuery().length() == 0) {
            loadList(); // Refresh only if not searching
        }
    }
}
