package com.example.culinarylab.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);

        DBHelper db = new DBHelper(this);

        EditText etUsername = findViewById(R.id.etUsername);
        EditText etPassword = findViewById(R.id.etPassword);
        EditText etPasswordConfirm = findViewById(R.id.etPasswordConfirm);
        Spinner spRole = findViewById(R.id.spRole);
        Button btnRegister = findViewById(R.id.btnRegister);
        TextView tvLoginLink = findViewById(R.id.tvLoginLink);

        // Setup Spinner Adapter
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.roles_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spRole.setAdapter(adapter);

        btnRegister.setOnClickListener(v -> {
            String user = etUsername.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();
            String confirmPass = etPasswordConfirm.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty() || confirmPass.isEmpty()) {
                Toast.makeText(this, "Harap isi semua field!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (spRole.getSelectedItem() == null) {
                Toast.makeText(this, "Harap pilih peran!", Toast.LENGTH_SHORT).show();
                return;
            }
            String role = spRole.getSelectedItem().toString().toLowerCase();

            if (!pass.equals(confirmPass)) {
                Toast.makeText(this, "Password tidak cocok!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                boolean success = db.registerUser(user, pass, role);

                if (success) {
                    Toast.makeText(this, "Registrasi berhasil! Silakan login.", Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    Toast.makeText(this, "Username sudah digunakan!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error Registrasi: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        // Login link
        tvLoginLink.setOnClickListener(v -> finish());
    }
}
