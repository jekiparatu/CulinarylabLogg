package com.example.culinarylab;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.culinarylab.models.Recipe;

import com.example.culinarylab.models.User;
import com.example.culinarylab.models.Video;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "culinarylab.db";
    public static final int DB_VERSION = 22; // Version 22: Fix Duplicate Table Creation

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        android.util.Log.d("DBHelper", "DBHelper initialized with version: " + DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TABLE USERS
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE, " +
                        "password TEXT, " +
                        "role TEXT, " +
                        "email TEXT, " +
                        "photoUri TEXT)");

        // TABLE CATEGORIES (New)
        db.execSQL(
                "CREATE TABLE categories (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT UNIQUE)");
        // Default categories
        db.execSQL("INSERT INTO categories(name) VALUES('Main Course')");
        db.execSQL("INSERT INTO categories(name) VALUES('Appetizer')");
        db.execSQL("INSERT INTO categories(name) VALUES('Dessert')");
        db.execSQL("INSERT INTO categories(name) VALUES('Beverage')");
        // Additional Categories (Indonesian & International)
        db.execSQL("INSERT INTO categories(name) VALUES('Makanan Berat')");
        db.execSQL("INSERT INTO categories(name) VALUES('Daging')");
        db.execSQL("INSERT INTO categories(name) VALUES('Cemilan')");
        db.execSQL("INSERT INTO categories(name) VALUES('Sarapan')");
        db.execSQL("INSERT INTO categories(name) VALUES('Minuman')");
        db.execSQL("INSERT INTO categories(name) VALUES('Jajanan Pasar')");
        db.execSQL("INSERT INTO categories(name) VALUES('Seafood')");
        db.execSQL("INSERT INTO categories(name) VALUES('Vegan')");
        db.execSQL("INSERT INTO categories(name) VALUES('Western')");
        db.execSQL("INSERT INTO categories(name) VALUES('Tradisional')");

        // Default Accounts
        db.execSQL("INSERT INTO users(username, password, role) VALUES('admin', 'admin123', 'admin')");
        db.execSQL("INSERT INTO users(username, password, role) VALUES('chef', 'chef123', 'chef')");
        db.execSQL("INSERT INTO users(username, password, role) VALUES('reviewer', 'review123', 'reviewer')");

        // TABLE RECIPES (Updated)
        db.execSQL(
                "CREATE TABLE recipes (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "title TEXT, " +
                        "ingredients TEXT, " +
                        "method TEXT, " +
                        "resultNote TEXT, " +
                        "rating INTEGER, " +
                        "reviewerComment TEXT, " +
                        "chefId INTEGER, " +
                        "regionalName TEXT, " +
                        "imageUri TEXT, " +
                        "categoryName TEXT)");

        // TABLE VIDEOS (New)
        db.execSQL(
                "CREATE TABLE videos (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "title TEXT, " +
                        "duration TEXT, " +
                        "category TEXT, " +
                        "thumbnail TEXT, " +
                        "videoUrl TEXT)");

        // TABLE REVIEWS (New)
        db.execSQL(
                "CREATE TABLE reviews (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "recipeId INTEGER, " +
                        "userId INTEGER, " +
                        "rating INTEGER, " +
                        "comment TEXT, " +
                        "date TEXT)");

        // TABLE FAVORITES (New)
        db.execSQL(
                "CREATE TABLE favorites (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "userId INTEGER, " +
                        "recipeId INTEGER)");

        // SAMPLE RECIPES (NTT Special)
        // 1. Jagung Bose
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Jagung Bose', " +
                        "'250 gr jagung bose, 100 gr kacang tanah, 400 ml santan, 2 siung bawang putih, Garam, Daun bawang', "
                        +
                        "'1. Rendam jagung semalaman.\\n2. Rebus jagung dan kacang hingga empuk.\\n3. Masukkan bawang putih dan santan.\\n4. Masak hingga kental.', "
                        +
                        "'Gurih dan creamy, cocok dengan ikan asin.', " +
                        "5, " +
                        "2, " +
                        "'Nusa Tenggara Timur', " +
                        "'img_jagung_bose', " +
                        "'Makanan Berat')");

        // 2. Se'i Sapi (Updated Image) - Moved to Daging category
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Se i Sapi (Daging Asap)', " +
                        "'1 kg daging sapi iris panjang, Garam kasar, Lada, Kayu kosambi/arang', " +
                        "'1. Lumuri daging dengan garam/lada.\\n2. Asap daging api kecil 3-4 jam.\\n3. Bolak-balik hingga matang merata, sajikan.', "
                        +
                        "'Aroma asap khas, tekstur juicy.', " +
                        "5, " +
                        "2, " +
                        "'Nusa Tenggara Timur', " +
                        "'img_sei_sapi_real', " +
                        "'Daging')");

        // 3. Sambal Lu'at (Updated Image)
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Sambal Lu at', " +
                        "'Cabai merah/rawit, 2 siung bawang merah, 1 tomat, jeruk nipis, minyak panas, garam', " +
                        "'1. Haluskan cabai, bawang, tomat.\\n2. Siram minyak panas.\\n3. Beri garam dan jeruk nipis, aduk rata.', "
                        +
                        "'Pedas segar, wajib untuk Se i.', " +
                        "4, " +
                        "2, " +
                        "'Nusa Tenggara Timur', " +
                        "'img_sambal_luat_real', " +
                        "'Tradisional')");

        // 4. Catemak Jagung
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Catemak Jagung', " +
                        "'Jagung pipil, Kacang hijau, Labu kuning/daun pepaya, Garam', " +
                        "'1. Rebus jagung & kacang hijau hingga empuk.\\n2. Masukkan sayuran.\\n3. Bumbui garam, masak hingga matang.', "
                        +
                        "'Makanan penutup atau utama yang sehat.', " +
                        "4, " +
                        "2, " +
                        "'Nusa Tenggara Timur', " +
                        "'img_catemak_jagung', " +
                        "'Makanan Berat')");

        // 5. Sup Ayam Sederhana
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Sup Ayam Sederhana', " +
                        "'250 g dada ayam/sayap ayam (potong kecil), 2 buah wortel (potong dadu), 1 buah kentang (potong dadu), 1 batang daun bawang (iris), 1 batang seledri (iris), 1 buah tomat (potong 4), 1 sdt kaldu ayam bubuk, ½ sdt merica bubuk, 2 siung bawang putih (geprek \u0026 cincang), 1 siung bawang merah (cincang), 1 liter air, Garam secukupnya, Minyak sedikit untuk menumis', "
                        +
                        "'1. Tumis bumbu: Panaskan sedikit minyak, tumis bawang putih dan bawang merah sampai harum.\\n2. Masak ayam: Masukkan potongan ayam, aduk sampai berubah warna.\\n3. Tambahkan air: Tuang 1 liter air, masak hingga mendidih.\\n4. Masukkan sayuran: Tambahkan wortel dan kentang. Masak hingga keduanya empuk.\\n5. Bumbui: Tambahkan garam, merica, dan kaldu bubuk. Aduk rata.\\n6. Tambahkan pelengkap: Masukkan tomat, daun bawang, dan seledri. Masak 1 menit saja.\\n7. Sajikan hangat dengan taburan bawang goreng.', "
                        +
                        "'Sup hangat yang segar dan bergizi. Cocok untuk segala cuaca!', " +
                        "5, " +
                        "2, " +
                        "'Indonesia', " +
                        "'img_sup_ayam', " +
                        "'Appetizer')");

        // 6. Gado-Gado (Indonesian Salad)
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Gado-Gado', " +
                        "'200 g kol (rebus), 100 g tauge (rebus), 2 buah kentang (rebus, potong), 2 buah wortel (rebus, potong), 100 g kacang panjang (rebus, potong), 2 butir telur (rebus), 1 buah timun (iris), Kerupuk, Bawang goreng, BUMBU KACANG: 200 g kacang tanah goreng, 3 siung bawang putih, 2 buah cabai merah, 1 sdm gula merah, 1 sdt terasi, Air asam jawa, Garam', "
                        +
                        "'1. Haluskan kacang tanah goreng, bawang putih, cabai, terasi, dan gula merah.\\n2. Tambahkan air secukupnya, masak bumbu kacang hingga mendidih dan kental.\\n3. Beri air asam jawa dan garam, aduk rata.\\n4. Tata sayuran rebus di piring: kol, tauge, kentang, wortel, kacang panjang.\\n5. Tambahkan telur rebus (belah dua) dan timun.\\n6. Siram dengan bumbu kacang.\\n7. Taburi bawang goreng dan sajikan dengan kerupuk.', "
                        +
                        "'Salad Indonesia yang kaya gizi dengan bumbu kacang yang gurih!', " +
                        "5, " +
                        "2, " +
                        "'Indonesia', " +
                        "'img_gado_gado', " +
                        "'Vegan')");

        // 7. Es Cendol
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Es Cendol', " +
                        "'CENDOL: 100 g tepung beras, 50 g tepung sagu, 400 ml air pandan (dari 10 lembar daun pandan), ½ sdt garam, KUAH: 200 ml santan kental, ½ sdt garam, 2 lembar daun pandan, SIRUP: 150 g gula merah, 100 ml air, 1 lembar daun pandan, Es batu secukupnya', "
                        +
                        "'1. BUAT CENDOL: Campur tepung beras, tepung sagu, air pandan, dan garam. Masak sambil diaduk hingga kental.\\n2. Saring adonan cendol ke dalam baskom berisi air es menggunakan cetakan cendol.\\n3. BUAT KUAH SANTAN: Rebus santan dengan garam dan daun pandan hingga mendidih. Dinginkan.\\n4. BUAT SIRUP: Rebus gula merah dengan air dan daun pandan hingga larut. Saring, dinginkan.\\n5. PENYAJIAN: Masukkan cendol ke gelas, tambahkan es batu, siram dengan sirup gula merah dan santan.\\n6. Sajikan dingin.', "
                        +
                        "'Minuman/dessert tradisional Indonesia yang segar dan manis!', " +
                        "5, " +
                        "2, " +
                        "'Indonesia', " +
                        "'img_es_cendol_new', " +
                        "'Dessert')");

        // 8. Sup Bakso
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Sup Bakso', " +
                        "'250 g bakso sapi, 100 g mie kuning, 2 batang daun bawang (iris), 2 batang seledri (iris), Bawang goreng, KUAH: 1 liter air, 2 siung bawang putih (geprek), 1 sdt kaldu sapi bubuk, Garam, Merica', "
                        +
                        "'1. Rebus air hingga mendidih, masukkan bawang putih geprek.\\n2. Tambahkan kaldu bubuk, garam, dan merica.\\n3. Masukkan bakso, masak hingga mengapung dan matang.\\n4. Rebus mie kuning terpisah hingga matang, tiriskan.\\n5. PENYAJIAN: Taruh mie di mangkuk, tambahkan bakso dan kuah panas.\\n6. Taburi daun bawang, seledri, dan bawang goreng.\\n7. Sajikan dengan sambal dan kecap.', "
                        +
                        "'Sup bakso favorit Indonesia yang hangat dan mengenyangkan!', " +
                        "5, " +
                        "2, " +
                        "'Indonesia', " +
                        "'img_sup_bakso', " +
                        "'Appetizer')");

        // 9. Soto Ayam
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Soto Ayam', " +
                        "'300 g ayam (rebus, suwir), 2 buah kentang (rebus, potong), 100 g tauge, 2 butir telur (rebus), 50 g soun, Daun bawang, Seledri, Bawang goreng, BUMBU: 4 siung bawang putih, 5 butir kemiri, 1 sdt kunyit bubuk, Jahe, Serai, Daun jeruk, 1 liter kaldu ayam, Garam, Merica', "
                        +
                        "'1. Haluskan bawang putih dan kemiri, tumis hingga harum.\\n2. Tambahkan kunyit, jahe, serai, dan daun jeruk.\\n3. Tuang kaldu ayam, masak hingga mendidih.\\n4. Bumbui dengan garam dan merica.\\n5. Rendam soun dalam air panas hingga lembut.\\n6. PENYAJIAN: Taruh soun, ayam suwir, kentang, tauge, dan telur di mangkuk.\\n7. Siram dengan kuah soto panas.\\n8. Taburi daun bawang, seledri, dan bawang goreng.', "
                        +
                        "'Soto ayam kuning yang harum dan segar!', " +
                        "5, " +
                        "2, " +
                        "'Indonesia', " +
                        "'img_soto_ayam', " +
                        "'Appetizer')");

        // 10. Rendang
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Rendang', " +
                        "'1 kg daging sapi (potong kotak), 1 liter santan, 3 lembar daun jeruk, 2 batang serai (geprek), 2 cm lengkuas (geprek), BUMBU HALUS: 8 siung bawang merah, 6 siung bawang putih, 5 buah cabai merah, 3 cm jahe, 2 cm kunyit, 1 sdm ketumbar, Garam, Gula merah', "
                        +
                        "'1. Haluskan semua bumbu halus.\\n2. Tumis bumbu halus hingga harum dan matang.\\n3. Masukkan daging, aduk hingga berubah warna.\\n4. Tuang santan, tambahkan daun jeruk, serai, dan lengkuas.\\n5. Masak dengan api kecil sambil terus diaduk hingga santan menyusut.\\n6. Tambahkan garam dan gula merah.\\n7. Masak terus hingga bumbu meresap dan daging empuk (2-3 jam).\\n8. Rendang siap saat berwarna coklat gelap dan berminyak.', "
                        +
                        "'Rendang Padang yang legendaris, kaya rempah dan empuk!', " +
                        "5, " +
                        "2, " +
                        "'Sumatera Barat', " +
                        "'img_rendang', " +
                        "'Daging')");

        // 11. Ayam Goreng
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Ayam Goreng Kremes', " +
                        "'1 ekor ayam (potong), Minyak untuk menggoreng, BUMBU HALUS: 5 siung bawang putih, 3 cm kunyit, 2 cm jahe, 1 sdt ketumbar, Garam, Gula, Air secukupnya, KREMESAN: Sisa bumbu ungkep + tepung beras', "
                        +
                        "'1. Haluskan semua bumbu, tambahkan air secukupnya.\\n2. Ungkep ayam dengan bumbu halus hingga meresap dan empuk (30 menit).\\n3. Angkat ayam, tiriskan (sisihkan sisa bumbu untuk kremesan).\\n4. Goreng ayam dengan minyak panas hingga kuning kecoklatan dan kering.\\n5. BUAT KREMESAN: Campur sisa bumbu ungkep dengan tepung beras dan sedikit air.\\n6. Siramkan adonan ke minyak panas, goreng hingga krispi.\\n7. Sajikan ayam goreng dengan kremesan, sambal, dan lalapan.', "
                        +
                        "'Ayam goreng krispi dengan kremesan yang gurih!', " +
                        "5, " +
                        "2, " +
                        "'Indonesia', " +
                        "'img_ayam_goreng', " +
                        "'Daging')");

        // 12. Asinan Jakarta
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Asinan Jakarta', " +
                        "'200 g kol (iris), 2 buah wortel (iris korek api), 1 buah timun (iris), 100 g tauge, 2 buah tahu goreng (potong), Kerupuk, Kacang tanah goreng, KUAH: 200 ml air, 100 ml cuka, 3 sdm gula pasir, 1 sdt garam, 2 buah cabai rawit (iris)', "
                        +
                        "'1. Rebus kol dan tauge sebentar, tiriskan.\\n2. BUAT KUAH: Campur air, cuka, gula, garam, dan cabai. Aduk hingga gula larut.\\n3. Masukkan kol, wortel, timun, dan tauge ke dalam mangkuk.\\n4. Tambahkan tahu goreng.\\n5. Siram dengan kuah asinan.\\n6. Taburi kacang goreng dan sajikan dengan kerupuk.\\n7. Sajikan dingin lebih segar.', "
                        +
                        "'Asinan segar khas Jakarta yang asam manis pedas!', " +
                        "4, " +
                        "2, " +
                        "'Jakarta', " +
                        "'img_asinan', " +
                        "'Vegan')");

        // 13. Karedok
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Karedok', " +
                        "'100 g kol (iris halus), 100 g tauge, 100 g kacang panjang (iris), 1 buah timun (iris), 1 buah terong (iris), Kerupuk, BUMBU KACANG: 150 g kacang tanah goreng, 3 siung bawang putih, 2 buah cabai rawit, 1 buah cabai merah, 1 sdt terasi bakar, 2 sdm gula merah, Air asam jawa, Garam', "
                        +
                        "'1. Siapkan semua sayuran mentah (tidak direbus).\\n2. BUAT BUMBU: Haluskan kacang tanah, bawang putih, cabai, dan terasi.\\n3. Tambahkan gula merah, air asam jawa, dan garam.\\n4. Beri air secukupnya hingga bumbu agak encer.\\n5. Tata sayuran di piring.\\n6. Siram dengan bumbu kacang.\\n7. Sajikan dengan kerupuk.', "
                        +
                        "'Salad sayuran mentah khas Sunda dengan bumbu kacang!', " +
                        "5, " +
                        "2, " +
                        "'Jawa Barat', " +
                        "'img_karedok', " +
                        "'Vegan')");

        // 14. Puding Karamel
        db.execSQL(
                "INSERT INTO recipes(title, ingredients, method, resultNote, rating, chefId, regionalName, imageUri, categoryName) VALUES("
                        +
                        "'Puding Karamel', " +
                        "'PUDING: 1 bungkus agar-agar plain, 100 g gula pasir, 500 ml susu cair, 500 ml air, 1 sdt vanili, KARAMEL: 100 g gula pasir, 50 ml air', "
                        +
                        "'1. BUAT KARAMEL: Masak gula dengan sedikit air hingga berwarna coklat keemasan.\\n2. Tuang karamel ke cetakan, ratakan.\\n3. BUAT PUDING: Campur agar-agar, gula, susu, air, dan vanili.\\n4. Masak sambil diaduk hingga mendidih.\\n5. Tuang adonan puding ke cetakan berisi karamel.\\n6. Dinginkan dalam kulkas hingga set (2-3 jam).\\n7. Keluarkan dari cetakan dengan cara dibalik.', "
                        +
                        "'Puding lembut dengan karamel manis yang sempurna!', " +
                        "5, " +
                        "2, " +
                        "'Indonesia', " +
                        "'img_puding', " +
                        "'Dessert')");

        // SAMPLE VIDEOS - Tutorial Masak
        // 1. Tutorial Rendang
        db.execSQL(
                "INSERT INTO videos(title, duration, category, videoUrl) VALUES(" +
                        "'Tutorial Membuat Rendang Padang Asli', " +
                        "'15:30', " +
                        "'Makanan Berat', " +
                        "'https://www.youtube.com/watch?v=dQw4w9WgXcQ')");

        // 2. Tutorial Soto Ayam
        db.execSQL(
                "INSERT INTO videos(title, duration, category, videoUrl) VALUES(" +
                        "'Cara Membuat Soto Ayam Kuning', " +
                        "'12:45', " +
                        "'Appetizer', " +
                        "'https://www.youtube.com/watch?v=dQw4w9WgXcQ')");

        // 3. Tutorial Gado-Gado
        db.execSQL(
                "INSERT INTO videos(title, duration, category, videoUrl) VALUES(" +
                        "'Membuat Gado-Gado dengan Bumbu Kacang', " +
                        "'10:20', " +
                        "'Vegan', " +
                        "'https://www.youtube.com/watch?v=dQw4w9WgXcQ')");

        // 4. Tutorial Nasi Goreng
        db.execSQL(
                "INSERT INTO videos(title, duration, category, videoUrl) VALUES(" +
                        "'Nasi Goreng Spesial Restoran', " +
                        "'08:15', " +
                        "'Makanan Berat', " +
                        "'https://www.youtube.com/watch?v=dQw4w9WgXcQ')");

        // 5. Tutorial Ayam Goreng
        db.execSQL(
                "INSERT INTO videos(title, duration, category, videoUrl) VALUES(" +
                        "'Ayam Goreng Kremes Renyah', " +
                        "'11:00', " +
                        "'Daging', " +
                        "'https://www.youtube.com/watch?v=dQw4w9WgXcQ')");

        // 6. Tutorial Es Cendol
        db.execSQL(
                "INSERT INTO videos(title, duration, category, videoUrl) VALUES(" +
                        "'Membuat Es Cendol Segar', " +
                        "'09:30', " +
                        "'Dessert', " +
                        "'https://www.youtube.com/watch?v=dQw4w9WgXcQ')");

        // 7. Tutorial Se'i Sapi
        db.execSQL(
                "INSERT INTO videos(title, duration, category, videoUrl) VALUES(" +
                        "'Se i Sapi NTT - Daging Asap Khas', " +
                        "'18:00', " +
                        "'Daging', " +
                        "'https://www.youtube.com/watch?v=dQw4w9WgXcQ')");
    }

    // ---------- USER METHODS ----------
    public boolean registerUser(String username, String password, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM users WHERE username = ?", new String[] { username });
        if (c.getCount() > 0) {
            c.close();
            return false;
        }
        c.close();

        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password);
        cv.put("role", role);
        long insert = db.insert("users", null, cv);
        return insert != -1;
    }

    public User authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id, username, role, email, photoUri FROM users WHERE username=? AND password=?",
                new String[] { username, password });
        if (c.moveToFirst()) {
            User user = new User();
            user.setId(c.getInt(0));
            user.setName(c.getString(1));
            user.setRole(c.getString(2));
            user.setEmail(c.getString(3));
            user.setPhotoUri(c.getString(4));
            c.close();
            return user;
        }
        c.close();
        return null;
    }

    public User getUserById(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id, username, role, email, photoUri FROM users WHERE id=?",
                new String[] { String.valueOf(userId) });
        if (c.moveToFirst()) {
            User user = new User();
            user.setId(c.getInt(0));
            user.setName(c.getString(1));
            user.setRole(c.getString(2));
            user.setEmail(c.getString(3));
            user.setPhotoUri(c.getString(4));
            c.close();
            return user;
        }
        c.close();
        return null;
    }

    public boolean updateUserProfile(int userId, String name, String email, String photoUri) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", name);
        cv.put("email", email);
        if (photoUri != null) {
            cv.put("photoUri", photoUri);
        }
        int result = db.update("users", cv, "id = ?", new String[] { String.valueOf(userId) });
        return result > 0;
    }

    public boolean updateUserPassword(int userId, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("password", newPassword);
        int result = db.update("users", cv, "id = ?", new String[] { String.valueOf(userId) });
        return result > 0;
    }

    public boolean verifyPassword(int userId, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM users WHERE id=? AND password=?",
                new String[] { String.valueOf(userId), password });
        boolean valid = c.getCount() > 0;
        c.close();
        return valid;
    }

    public List<User> getAllUsers() { // For Admin
        List<User> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM users", null);
        if (c.moveToFirst()) {
            do {
                User u = new User();
                u.setId(c.getInt(0));
                u.setName(c.getString(1));
                u.setPassword(c.getString(2));
                u.setRole(c.getString(3));
                list.add(u);
            } while (c.moveToNext());
        }
        c.close();
        return list;
    }

    public boolean deleteUser(int id) { // For Admin
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("users", "id=?", new String[] { String.valueOf(id) }) > 0;
    }

    // ---------- CATEGORY METHODS ----------
    public List<String> getAllCategories() {
        List<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT name FROM categories", null);
        if (c.moveToFirst()) {
            do {
                list.add(c.getString(0));
            } while (c.moveToNext());
        }
        c.close();
        return list;
    }

    public boolean addCategory(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        long result = db.insert("categories", null, cv);
        return result != -1;
    }

    public boolean deleteCategory(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("categories", "name = ?", new String[] { name }) > 0;
    }

    // ---------- RECIPE METHODS ----------
    public long addRecipe(Recipe recipe) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", recipe.getTitle());
        cv.put("ingredients", recipe.getIngredients());
        cv.put("method", recipe.getMethod());
        cv.put("resultNote", recipe.getResultNote());
        cv.put("rating", recipe.getRating());
        cv.put("reviewerComment", recipe.getReviewerComment());
        cv.put("chefId", recipe.getChefId());
        // v2 columns
        cv.put("regionalName", recipe.getRegionalName());
        cv.put("imageUri", recipe.getImageUri());
        cv.put("categoryName", recipe.getCategoryName());

        return db.insert("recipes", null, cv);
    }

    public Recipe getRecipeById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT r.*, u.username AS chefName FROM recipes r LEFT JOIN users u ON r.chefId = u.id WHERE r.id = ?",
                new String[] { String.valueOf(id) });
        if (c.moveToFirst()) {
            Recipe recipe = mapCursorToRecipe(c);
            c.close();
            return recipe;
        }
        c.close();
        return null;
    }

    public boolean updateRecipe(Recipe recipe) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", recipe.getTitle());
        cv.put("ingredients", recipe.getIngredients());
        cv.put("method", recipe.getMethod());
        cv.put("resultNote", recipe.getResultNote());
        cv.put("rating", recipe.getRating());
        cv.put("reviewerComment", recipe.getReviewerComment());
        // v2 columns
        cv.put("regionalName", recipe.getRegionalName());
        cv.put("imageUri", recipe.getImageUri());
        cv.put("categoryName", recipe.getCategoryName());

        int result = db.update("recipes", cv, "id = ?", new String[] { String.valueOf(recipe.getId()) });
        return result > 0;
    }

    public boolean deleteRecipe(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("recipes", "id = ?", new String[] { String.valueOf(id) });
        return result > 0;
    }

    public List<Recipe> getAllRecipes() {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Recipe> recipeList = new ArrayList<>();
        // JOIN to get chef name
        Cursor c = db.rawQuery("SELECT r.*, u.username AS chefName FROM recipes r LEFT JOIN users u ON r.chefId = u.id",
                null);

        android.util.Log.d("DBHelper", "getAllRecipes() called");
        android.util.Log.d("DBHelper", "Cursor count: " + c.getCount());

        if (c.moveToFirst()) {
            do {
                recipeList.add(mapCursorToRecipe(c));
            } while (c.moveToNext());
        }
        c.close();

        android.util.Log.d("DBHelper", "Total recipes returned: " + recipeList.size());
        return recipeList;
    }

    public List<Recipe> getRecipesByChef(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Recipe> recipeList = new ArrayList<>();
        Cursor c = db.rawQuery(
                "SELECT r.*, u.username AS chefName FROM recipes r LEFT JOIN users u ON r.chefId = u.id WHERE r.chefId = ?",
                new String[] { String.valueOf(userId) });
        if (c.moveToFirst()) {
            do {
                recipeList.add(mapCursorToRecipe(c));
            } while (c.moveToNext());
        }
        c.close();
        return recipeList;
    }

    // Search
    public List<Recipe> getRecipesBySearch(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Recipe> recipeList = new ArrayList<>();
        String likeQuery = "%" + query + "%";
        Cursor c = db.rawQuery(
                "SELECT r.*, u.username AS chefName FROM recipes r LEFT JOIN users u ON r.chefId = u.id WHERE r.title LIKE ? OR r.ingredients LIKE ?",
                new String[] { likeQuery, likeQuery });
        if (c.moveToFirst()) {
            do {
                recipeList.add(mapCursorToRecipe(c));
            } while (c.moveToNext());
        }
        c.close();
        return recipeList;
    }

    // ---------- REVIEW METHODS ----------
    public boolean addReview(com.example.culinarylab.models.Review review) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("recipeId", review.getRecipeId());
        cv.put("userId", review.getUserId());
        cv.put("rating", review.getRating());
        cv.put("comment", review.getComment());
        cv.put("date", review.getDate()); // Simple string date
        long res = db.insert("reviews", null, cv);
        return res != -1;
    }

    public List<com.example.culinarylab.models.Review> getReviewsByRecipe(int recipeId) {
        List<com.example.culinarylab.models.Review> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        // Join with users to get reviewer name directly
        Cursor c = db.rawQuery("SELECT r.id, r.recipeId, r.userId, r.rating, r.comment, r.date, u.username " +
                "FROM reviews r LEFT JOIN users u ON r.userId = u.id WHERE r.recipeId = ?",
                new String[] { String.valueOf(recipeId) });

        if (c.moveToFirst()) {
            do {
                com.example.culinarylab.models.Review r = new com.example.culinarylab.models.Review();
                r.setId(c.getInt(0));
                r.setRecipeId(c.getInt(1));
                r.setUserId(c.getInt(2));
                r.setRating(c.getInt(3));
                r.setComment(c.getString(4));
                r.setDate(c.getString(5));
                r.setReviewerName(c.getString(6));
                list.add(r);
            } while (c.moveToNext());
        }
        c.close();
        return list;
    }

    // ---------- FAVORITE METHODS ----------
    public boolean isFavorite(int userId, int recipeId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM favorites WHERE userId = ? AND recipeId = ?",
                new String[] { String.valueOf(userId), String.valueOf(recipeId) });
        boolean exists = c.getCount() > 0;
        c.close();
        return exists;
    }

    public void setFavorite(int userId, int recipeId, boolean isFavorite) {
        SQLiteDatabase db = this.getWritableDatabase();
        if (isFavorite) {
            if (!isFavorite(userId, recipeId)) {
                ContentValues cv = new ContentValues();
                cv.put("userId", userId);
                cv.put("recipeId", recipeId);
                db.insert("favorites", null, cv);
            }
        } else {
            db.delete("favorites", "userId = ? AND recipeId = ?",
                    new String[] { String.valueOf(userId), String.valueOf(recipeId) });
        }
    }

    public List<Recipe> getFavoriteRecipes(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Recipe> list = new ArrayList<>();
        // Join favorites -> recipes -> users
        String query = "SELECT r.*, u.username AS chefName FROM favorites f " +
                "JOIN recipes r ON f.recipeId = r.id " +
                "LEFT JOIN users u ON r.chefId = u.id " +
                "WHERE f.userId = ?";

        Cursor c = db.rawQuery(query, new String[] { String.valueOf(userId) });
        if (c.moveToFirst()) {
            do {
                list.add(mapCursorToRecipe(c));
            } while (c.moveToNext());
        }
        c.close();
        return list;
    }

    public List<Recipe> getRecipesByCategory(String category) {
        android.util.Log.d("DBHelper", "getRecipesByCategory called with: " + category);

        SQLiteDatabase db = this.getReadableDatabase();
        List<Recipe> recipeList = new ArrayList<>();

        if (category == null || category.isEmpty()) {
            android.util.Log.w("DBHelper", "Category is null or empty, returning empty list");
            return recipeList;
        }

        Cursor c = db.rawQuery(
                "SELECT r.*, u.username AS chefName FROM recipes r LEFT JOIN users u ON r.chefId = u.id WHERE r.categoryName = ?",
                new String[] { category });

        android.util.Log.d("DBHelper", "Found " + c.getCount() + " recipes for category: " + category);

        if (c.moveToFirst()) {
            do {
                recipeList.add(mapCursorToRecipe(c));
            } while (c.moveToNext());
        }
        c.close();

        android.util.Log.d("DBHelper", "Returning " + recipeList.size() + " recipes");
        return recipeList;
    }

    private Recipe mapCursorToRecipe(Cursor c) {
        Recipe recipe = new Recipe();
        try {
            recipe.setId(c.getInt(0));
            recipe.setTitle(c.getString(1));
            recipe.setIngredients(c.getString(2));
            recipe.setMethod(c.getString(3));
            recipe.setResultNote(c.getString(4));
            recipe.setRating(c.getInt(5));
            recipe.setReviewerComment(c.getString(6));
            recipe.setChefId(c.getInt(7));

            // Check if newer columns exist in this cursor
            if (c.getColumnCount() > 8) {
                recipe.setRegionalName(c.getString(8));
                recipe.setImageUri(c.getString(9));
                recipe.setCategoryName(c.getString(10));
            }
            // chefName is likely the last column due to JOIN
            int nameIndex = c.getColumnIndex("chefName");
            if (nameIndex != -1) {
                recipe.setChefName(c.getString(nameIndex));
            }
        } catch (Exception e) {
            // Log or ignore schema mismatch
            e.printStackTrace();
        }
        return recipe;
    }

    // ---------- VIDEO METHODS (New) ----------
    public boolean addVideo(Video video) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", video.getTitle());
        cv.put("duration", video.getDuration());
        cv.put("category", video.getCategory());
        cv.put("thumbnail", video.getVideoThumbnail());
        cv.put("videoUrl", video.getVideoUrl());
        long res = db.insert("videos", null, cv);
        return res != -1;
    }

    public List<Video> getAllVideos() {
        List<Video> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM videos", null);
        if (c.moveToFirst()) {
            do {
                Video v = new Video();
                v.setId(c.getInt(0));
                v.setTitle(c.getString(1));
                v.setDuration(c.getString(2));
                v.setCategory(c.getString(3));
                v.setVideoThumbnail(c.getString(4));
                if (c.getColumnCount() > 5) {
                    v.setVideoUrl(c.getString(5));
                }
                list.add(v);
            } while (c.moveToNext());
        }
        c.close();
        return list;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if existed
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS categories");
        db.execSQL("DROP TABLE IF EXISTS recipes");
        db.execSQL("DROP TABLE IF EXISTS videos");
        db.execSQL("DROP TABLE IF EXISTS reviews");
        db.execSQL("DROP TABLE IF EXISTS favorites"); // Add this

        // Create tables again
        onCreate(db);
    }
}
