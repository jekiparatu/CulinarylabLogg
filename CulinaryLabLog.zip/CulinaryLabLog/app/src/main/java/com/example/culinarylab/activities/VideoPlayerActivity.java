package com.example.culinarylab.activities;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.culinarylab.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VideoPlayerActivity extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        webView = findViewById(R.id.webViewPlayer);

        String url = getIntent().getStringExtra("videoUrl");
        if (url == null || url.isEmpty()) {
            Toast.makeText(this, "URL Video tidak valid", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Extract Video ID to use Embed Format (Required for smooth embed play)
        String videoId = extractVideoId(url);
        if (videoId != null) {
            String embedUrl = "https://www.youtube.com/embed/" + videoId + "?autoplay=1&fs=1&rel=0";
            setupWebView(embedUrl);
        } else {
            // Fallback: Just load the URL directly might still work mobile web
            setupWebView(url);
        }
    }

    private void setupWebView(String url) {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());

        webView.loadUrl(url);
    }

    private String extractVideoId(String ytUrl) {
        String videoId = null;
        String regex = "^(https?://)?(www\\.)?(youtube\\.com|youtu\\.?be)/.*(watch\\?v=|embed/|v/|.+\\?v=)?([^&=%\\?]{11})";
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(ytUrl);
        if (matcher.find()) {
            videoId = matcher.group(5);
        }
        return videoId;
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }
}
