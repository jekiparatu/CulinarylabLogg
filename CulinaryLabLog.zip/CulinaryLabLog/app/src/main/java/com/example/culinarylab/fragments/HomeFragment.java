package com.example.culinarylab.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;
import com.example.culinarylab.activities.AddEditRecipeActivity;
import com.example.culinarylab.activities.AdminCategoryActivity;
import com.example.culinarylab.activities.AdminUserActivity;
import com.example.culinarylab.activities.RecipeDetailActivity;
import com.example.culinarylab.activities.RecipeListActivity;
import com.example.culinarylab.models.Recipe;
import com.example.culinarylab.models.User;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    TextView tvWelcome, tvRole;
    Button btnList, btnManageUsers, btnManageCategories, btnMyFavorites;
    RecyclerView rvCategories, rvRecommendations;
    FloatingActionButton fabAddRecipe;

    DBHelper dbHelper;
    String username;
    String role;
    int userId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        dbHelper = new DBHelper(getActivity());

        try {
            // View Bindings
            tvWelcome = view.findViewById(R.id.tvWelcome);
            tvRole = view.findViewById(R.id.tvRole);
            btnList = view.findViewById(R.id.btnViewRecipes);
            btnMyFavorites = view.findViewById(R.id.btnMyFavorites);
            btnManageUsers = view.findViewById(R.id.btnManageUsers);
            btnManageCategories = view.findViewById(R.id.btnManageCategories);
            rvCategories = view.findViewById(R.id.rvCategories);
            rvRecommendations = view.findViewById(R.id.rvRecommendations);
            fabAddRecipe = view.findViewById(R.id.fabAddRecipe);

            // Get Arguments
            if (getArguments() != null) {
                username = getArguments().getString("username");
                role = getArguments().getString("role");
                userId = getArguments().getInt("userId", -1);
            }

            // Defaults
            if (username == null)
                username = "User";
            if (role == null)
                role = "guest";

            // Set Header Text
            String welcomeEmoji = " \uD83D\uDC69\u200D\uD83C\uDF73"; // Default Cook Emoji
            tvWelcome.setText("Selamat datang, " + username + welcomeEmoji);
            tvRole.setText(role.toUpperCase());

            // Apply role-based gradient background
            LinearLayout homeHeader = view.findViewById(R.id.homeHeader);
            int gradientResource = R.drawable.gradient_background; // default

            if (role != null) {
                switch (role.toLowerCase()) {
                    case "admin":
                        gradientResource = R.drawable.gradient_admin;
                        welcomeEmoji = " \uD83D\uDC68\u200D\uD83D\uDCBC"; // Admin emoji
                        break;
                    case "chef":
                        gradientResource = R.drawable.gradient_chef;
                        welcomeEmoji = " \uD83D\uDC68\u200D\uD83C\uDF73"; // Chef emoji
                        break;
                    case "reviewer":
                        gradientResource = R.drawable.gradient_reviewer;
                        welcomeEmoji = " \u2B50"; // Reviewer emoji
                        break;
                }
                tvWelcome.setText("Selamat datang, " + username + welcomeEmoji);
            }

            if (homeHeader != null) {
                homeHeader.setBackgroundResource(gradientResource);
            }

            // Visibility Logic for Admin
            if (role.equals("admin")) {
                btnManageUsers.setVisibility(View.VISIBLE);
                btnManageCategories.setVisibility(View.VISIBLE);
            }

            // --- Categories Setup ---
            setupCategories();

            // --- Recommendations Setup ---
            setupRecommendations();

            // --- Listeners ---
            final String finalRole = role;

            btnList.setOnClickListener(v -> {
                Intent i = new Intent(getActivity(), RecipeListActivity.class);
                i.putExtra("userId", userId);
                i.putExtra("role", finalRole);
                startActivity(i);
            });

            if (btnMyFavorites != null) {
                btnMyFavorites.setOnClickListener(v -> {
                    Intent i = new Intent(getActivity(), RecipeListActivity.class);
                    i.putExtra("userId", userId);
                    i.putExtra("role", finalRole);
                    i.putExtra("showFavorites", true);
                    startActivity(i);
                });
            }

            btnManageUsers.setOnClickListener(
                    v -> startActivity(new Intent(getActivity(), AdminUserActivity.class)));

            btnManageCategories.setOnClickListener(
                    v -> startActivity(new Intent(getActivity(), AdminCategoryActivity.class)));

            fabAddRecipe.setOnClickListener(v -> {
                if (role.equals("reviewer")) {
                    Toast.makeText(getActivity(), "Reviewer tidak dapat menambah resep.", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent i = new Intent(getActivity(), AddEditRecipeActivity.class);
                i.putExtra("mode", "add");
                i.putExtra("userId", userId);
                i.putExtra("role", finalRole);
                startActivity(i);
            });

        } catch (Exception e) {
            Toast.makeText(getActivity(), "Error Home Fragment: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh Recommendation list when returning (e.g. after adding recipe)
        setupRecommendations();
    }

    private void setupCategories() {
        try {
            // Hardcoded categories for visual demo as per request
            List<CategoryItem> categoryList = new ArrayList<>();
            categoryList.add(new CategoryItem("Sup", R.drawable.ic_soup));
            categoryList.add(new CategoryItem("Daging", R.drawable.ic_meat));
            categoryList.add(new CategoryItem("Salad", R.drawable.ic_salad));
            categoryList.add(new CategoryItem("Dessert", R.drawable.ic_dessert));
            // Duplicates to fill grid if needed, or query actual categories in future

            CategoryAdapter adapter = new CategoryAdapter(getActivity(), categoryList);
            rvCategories.setLayoutManager(new GridLayoutManager(getActivity(), 2)); // 2 Columns
            rvCategories.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupRecommendations() {
        try {
            List<Recipe> recipes = dbHelper.getAllRecipes();
            // In a real app we might limit this or sort by date.
            // For now, taking last 5 for "Recent"
            List<Recipe> recentRecipes = new ArrayList<>();
            if (recipes != null) {
                int count = 0;
                for (int i = recipes.size() - 1; i >= 0; i--) {
                    recentRecipes.add(recipes.get(i));
                    count++;
                    if (count >= 5)
                        break;
                }
            }

            if (recentRecipes.isEmpty()) {
                // Optional: Show empty state
            }

            RecipeHorizontalAdapter adapter = new RecipeHorizontalAdapter(getActivity(), recentRecipes, username, role,
                    userId);
            rvRecommendations
                    .setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
            rvRecommendations.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Helper method to load recipe images from either drawable resource names or
     * file URIs
     */
    private void loadRecipeImage(ImageView imageView, String imageUri) {
        if (imageUri == null || imageUri.isEmpty()) {
            imageView.setImageResource(R.drawable.placeholder_recipe);
            return;
        }

        // Check if it's a drawable resource name (no slashes or colons)
        if (!imageUri.contains("/") && !imageUri.contains(":")) {
            // It's a drawable resource name like "img_jagung_bose"
            int resId = getResources().getIdentifier(imageUri, "drawable", getActivity().getPackageName());
            if (resId != 0) {
                imageView.setImageResource(resId);
            } else {
                imageView.setImageResource(R.drawable.placeholder_recipe);
            }
        } else {
            // It's a file URI
            try {
                imageView.setImageURI(Uri.parse(imageUri));
            } catch (Exception e) {
                imageView.setImageResource(R.drawable.placeholder_recipe);
            }
        }
    }

    // --- Inner Classes for Adapters & Models ---

    // 1. Category Model
    static class CategoryItem {
        String name;
        int iconRes;

        public CategoryItem(String name, int iconRes) {
            this.name = name;
            this.iconRes = iconRes;
        }
    }

    // 2. Category Adapter
    class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {
        List<CategoryItem> mList;
        Context mContext;

        public CategoryAdapter(Context context, List<CategoryItem> list) {
            this.mContext = context;
            this.mList = list;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category_card, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            CategoryItem item = mList.get(position);
            holder.tvName.setText(item.name);
            holder.imgIcon.setImageResource(item.iconRes);

            holder.itemView.setOnClickListener(v -> {
                // Map UI category names to database category names
                String dbCategoryName = mapCategoryToDatabase(item.name);

                // Navigate to RecipeListActivity with category filter
                Intent intent = new Intent(mContext, RecipeListActivity.class);
                intent.putExtra("userId", userId);
                intent.putExtra("role", role);
                intent.putExtra("category", dbCategoryName);
                mContext.startActivity(intent);
            });
        }

        /**
         * Maps UI category display names to actual database category names
         */
        private String mapCategoryToDatabase(String uiCategoryName) {
            switch (uiCategoryName) {
                case "Sup":
                    return "Appetizer";
                case "Daging":
                    return "Daging"; // Updated to use dedicated Daging category
                case "Salad":
                    return "Vegan"; // Or create a "Salad" category in database
                case "Dessert":
                    return "Dessert";
                default:
                    return uiCategoryName;
            }
        }

        @Override
        public int getItemCount() {
            return mList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvName;
            ImageView imgIcon;

            ViewHolder(View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvCategoryName);
                imgIcon = itemView.findViewById(R.id.imgCategory);
            }
        }
    }

    // 3. Recipe Horizontal Adapter
    class RecipeHorizontalAdapter extends RecyclerView.Adapter<RecipeHorizontalAdapter.ViewHolder> {
        List<Recipe> mList;
        Context mContext;
        String mUsername;
        String mRole;
        int mUserId;

        public RecipeHorizontalAdapter(Context context, List<Recipe> list, String username, String role, int userId) {
            this.mContext = context;
            this.mList = list;
            this.mUsername = username;
            this.mRole = role;
            this.mUserId = userId;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recipe_horizontal, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Recipe recipe = mList.get(position);
            holder.tvName.setText(recipe.getTitle());

            String cat = recipe.getCategoryName();
            if (cat == null || cat.isEmpty())
                cat = "Umum";
            holder.tvCategory.setText(cat);

            if (recipe.getImageUri() != null && !recipe.getImageUri().isEmpty()) {
                loadRecipeImage(holder.imgRecipe, recipe.getImageUri());
            } else {
                holder.imgRecipe.setImageResource(R.drawable.placeholder_recipe); // Fallback
            }

            holder.itemView.setOnClickListener(v -> {
                Intent i = new Intent(mContext, RecipeDetailActivity.class);
                i.putExtra("recipeId", recipe.getId());
                i.putExtra("userId", mUserId);
                i.putExtra("username", mUsername);
                i.putExtra("role", mRole);
                mContext.startActivity(i);
            });
        }

        @Override
        public int getItemCount() {
            return mList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvCategory;
            ImageView imgRecipe;

            ViewHolder(View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvRecipeName);
                tvCategory = itemView.findViewById(R.id.tvRecipeCategory);
                imgRecipe = itemView.findViewById(R.id.imgRecipe);
            }
        }
    }
}
