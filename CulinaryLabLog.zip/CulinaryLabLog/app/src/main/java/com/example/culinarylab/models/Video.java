package com.example.culinarylab.models;

public class Video {
    private int id;
    private String title;
    private String duration;
    private String category;
    private String videoThumbnail; // Uri string
    private String videoUrl; // YouTube Link

    public Video() {
    }

    public Video(String title, String duration, String category, String videoThumbnail, String videoUrl) {
        this.title = title;
        this.duration = duration;
        this.category = category;
        this.videoThumbnail = videoThumbnail;
        this.videoUrl = videoUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getVideoThumbnail() {
        return videoThumbnail;
    }

    public void setVideoThumbnail(String videoThumbnail) {
        this.videoThumbnail = videoThumbnail;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}
