package com.example.culinarylab.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;
import com.example.culinarylab.activities.AddVideoActivity;
import com.example.culinarylab.models.Video;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class VideoFragment extends Fragment {

    EditText etSearch;
    RecyclerView rvVideos;
    ExtendedFloatingActionButton fabUpload;
    LinearLayout layoutEmpty;

    DBHelper db;
    VideoAdapter adapter;
    List<Video> fullList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_video, container, false);

        db = new DBHelper(getActivity());

        etSearch = view.findViewById(R.id.etSearchVideo);
        rvVideos = view.findViewById(R.id.rvVideos);
        fabUpload = view.findViewById(R.id.fabUploadVideo);
        layoutEmpty = view.findViewById(R.id.layoutEmptyState);

        // Get role from Arguments (passed from DashboardActivity)
        String role = "guest"; // Default
        if (getArguments() != null) {
            role = getArguments().getString("role");
        }

        if (role == null)
            role = "guest";

        if ("admin".equals(role)) {
            fabUpload.setVisibility(View.VISIBLE);
        } else {
            fabUpload.setVisibility(View.GONE);
        }

        setupRecyclerView();

        fabUpload.setOnClickListener(v -> startActivity(new Intent(getActivity(), AddVideoActivity.class)));

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadVideos();
    }

    private void setupRecyclerView() {
        rvVideos.setLayoutManager(new LinearLayoutManager(getActivity()));
        fullList = new ArrayList<>();
        adapter = new VideoAdapter(getActivity(), fullList);
        rvVideos.setAdapter(adapter);
    }

    private void loadVideos() {
        try {
            fullList.clear();
            fullList.addAll(db.getAllVideos());

            if (fullList.isEmpty()) {
                layoutEmpty.setVisibility(View.VISIBLE);
                rvVideos.setVisibility(View.GONE);
            } else {
                layoutEmpty.setVisibility(View.GONE);
                rvVideos.setVisibility(View.VISIBLE);
            }
            adapter.updateList(fullList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void filter(String text) {
        List<Video> filtered = new ArrayList<>();
        for (Video v : fullList) {
            if (v.getTitle().toLowerCase().contains(text.toLowerCase()) ||
                    v.getCategory().toLowerCase().contains(text.toLowerCase())) {
                filtered.add(v);
            }
        }
        adapter.updateList(filtered);
    }

    class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.Holder> {
        List<Video> mList;
        Context context;

        public VideoAdapter(Context context, List<Video> list) {
            this.context = context;
            this.mList = new ArrayList<>(list);
        }

        public void updateList(List<Video> newList) {
            mList.clear();
            mList.addAll(newList);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(context).inflate(R.layout.item_video_card, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            Video v = mList.get(position);
            holder.tvTitle.setText(v.getTitle());
            holder.tvDuration.setText(v.getDuration());
            holder.tvCategory.setText(v.getCategory());

            if (v.getVideoThumbnail() != null) {
                holder.imgThumb.setImageURI(Uri.parse(v.getVideoThumbnail()));
            } else {
                holder.imgThumb.setImageResource(R.drawable.ic_launcher_background);
            }

            // On Click
            holder.itemView.setOnClickListener(view -> {
                if (v.getVideoUrl() != null && !v.getVideoUrl().isEmpty()) {
                    Intent i = new Intent(context, com.example.culinarylab.activities.VideoPlayerActivity.class);
                    i.putExtra("videoUrl", v.getVideoUrl());
                    context.startActivity(i);
                } else {
                    Toast.makeText(context, "Playing (No URL): " + v.getTitle(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return mList.size();
        }

        class Holder extends RecyclerView.ViewHolder {
            TextView tvTitle, tvDuration, tvCategory;
            ImageView imgThumb;

            Holder(View itemView) {
                super(itemView);
                tvTitle = itemView.findViewById(R.id.tvVideoTitle);
                tvDuration = itemView.findViewById(R.id.tvDuration);
                tvCategory = itemView.findViewById(R.id.tvVideoCategory);
                imgThumb = itemView.findViewById(R.id.imgThumbnail);
            }
        }
    }
}
