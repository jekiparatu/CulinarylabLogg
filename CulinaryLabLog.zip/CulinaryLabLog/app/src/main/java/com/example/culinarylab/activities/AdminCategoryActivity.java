package com.example.culinarylab.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;

import java.util.List;

public class AdminCategoryActivity extends AppCompatActivity {

    EditText etNewCategory;
    Button btnAdd;
    ListView lvCategories;
    DBHelper db;
    CategoryAdapter adapter;
    List<String> categories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_category);

        db = new DBHelper(this);

        etNewCategory = findViewById(R.id.etNewCategory);
        btnAdd = findViewById(R.id.btnAddCategory);
        lvCategories = findViewById(R.id.lvCategories);

        loadCategories();

        btnAdd.setOnClickListener(v -> {
            String name = etNewCategory.getText().toString().trim();
            if (name.isEmpty()) {
                Toast.makeText(this, "Empty name!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (db.addCategory(name)) {
                Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show();
                etNewCategory.setText("");
                loadCategories();
            } else {
                Toast.makeText(this, "Failed (Duplicate?)", Toast.LENGTH_SHORT).show();
            }
        });

        lvCategories.setOnItemLongClickListener((parent, view, position, id) -> {
            String name = categories.get(position);
            new AlertDialog.Builder(this)
                    .setTitle("Delete Category")
                    .setMessage("Delete " + name + "?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        if (db.deleteCategory(name)) {
                            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                            loadCategories();
                        } else {
                            Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("No", null)
                    .show();
            return true;
        });
    }

    private void loadCategories() {
        categories = db.getAllCategories();
        adapter = new CategoryAdapter(this, categories);
        lvCategories.setAdapter(adapter);
    }

    class CategoryAdapter extends BaseAdapter {
        Context context;
        List<String> list;

        public CategoryAdapter(Context context, List<String> list) {
            this.context = context;
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.item_admin_category, parent, false);
            }

            String name = list.get(position);
            TextView tvName = convertView.findViewById(R.id.tvCategoryName);
            tvName.setText(name);

            return convertView;
        }
    }
}
