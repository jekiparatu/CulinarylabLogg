package com.example.culinarylab.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.models.Recipe;
import com.example.culinarylab.R;

import java.util.List;

public class AddEditRecipeActivity extends AppCompatActivity {

    EditText etTitle, etIngredients, etMethod, etResult, etRegionalName;
    Spinner spCategory;
    ImageView ivRecipeImage;
    Button btnSave, btnDelete;
    com.google.android.material.floatingactionbutton.FloatingActionButton btnPickImage;

    DBHelper db;
    int userId;
    String userRole;
    String mode;

    int recipeId = -1;
    Recipe currentRecipe;
    Uri selectedImageUri = null;

    // Image Picker Result Launcher
    ActivityResultLauncher<String> mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    selectedImageUri = uri;
                    ivRecipeImage.setImageURI(uri);
                    // Persist permission (simplified approach)
                    try {
                        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            setContentView(R.layout.activity_add_edit_recipe);
            db = new DBHelper(this);

            // Setup Toolbar
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setDisplayShowHomeEnabled(true);
            }
            toolbar.setNavigationOnClickListener(v -> finish());

            // Bind Views
            etTitle = findViewById(R.id.etTitle);
            etIngredients = findViewById(R.id.etIngredients);
            etMethod = findViewById(R.id.etMethod);
            etResult = findViewById(R.id.etResultNote);
            etRegionalName = findViewById(R.id.etRegionalName);
            spCategory = findViewById(R.id.spCategory);
            ivRecipeImage = findViewById(R.id.ivRecipeImage);
            btnPickImage = findViewById(R.id.btnPickImage);
            btnSave = findViewById(R.id.btnSave);
            btnDelete = findViewById(R.id.btnDelete);

            // Setup Categories
            loadCategories();

            // Setup Image Picker
            View.OnClickListener pickImageListener = v -> mGetContent.launch("image/*");
            btnPickImage.setOnClickListener(pickImageListener);
            ivRecipeImage.setOnClickListener(pickImageListener); // Make the whole image area clickable

            // Get intent extras
            userId = getIntent().getIntExtra("userId", -1);
            userRole = getIntent().getStringExtra("role");
            mode = getIntent().getStringExtra("mode");

            if (userId == -1 || userRole == null || mode == null) {
                Toast.makeText(this, "Data tidak valid", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // ======================= MODE EDIT ===========================
            if (mode.equals("edit")) {
                // Update toolbar title
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setTitle("Edit Resep");
                }

                recipeId = getIntent().getIntExtra("recipeId", -1);
                currentRecipe = db.getRecipeById(recipeId);

                if (currentRecipe == null) {
                    Toast.makeText(this, "Resep tidak ditemukan", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }

                // Populate fields
                etTitle.setText(currentRecipe.getTitle());
                etIngredients.setText(currentRecipe.getIngredients());
                etMethod.setText(currentRecipe.getMethod());
                etResult.setText(currentRecipe.getResultNote());
                etRegionalName.setText(currentRecipe.getRegionalName());

                // Set Category Spinner
                selectSpinnerItemByValue(spCategory, currentRecipe.getCategoryName());

                // Set Image
                if (currentRecipe.getImageUri() != null && !currentRecipe.getImageUri().isEmpty()) {
                    selectedImageUri = Uri.parse(currentRecipe.getImageUri());
                    ivRecipeImage.setImageURI(selectedImageUri);
                }

                // Logic role
                if (userRole.equals("reviewer")) {
                    disableInputs();
                } else {
                    btnDelete.setVisibility(View.VISIBLE);
                }

            } else if (mode.equals("add")) {
                // Update toolbar title
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setTitle("Tambah Resep");
                }
                btnDelete.setVisibility(View.GONE);
            }

            // ======================= BUTTON SAVE ===========================
            btnSave.setOnClickListener(v -> saveRecipe());

            // ======================= BUTTON DELETE ===========================
            btnDelete.setOnClickListener(v -> deleteRecipe());

        } catch (Exception e) {
            Toast.makeText(this, "Error Init: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void loadCategories() {
        List<String> categories = db.getAllCategories();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(adapter);
    }

    private void selectSpinnerItemByValue(Spinner sp, String value) {
        if (value == null)
            return;
        ArrayAdapter adapter = (ArrayAdapter) sp.getAdapter();
        for (int position = 0; position < adapter.getCount(); position++) {
            if (adapter.getItem(position).toString().equals(value)) {
                sp.setSelection(position);
                return;
            }
        }
    }

    private void disableInputs() {
        etTitle.setEnabled(false);
        etIngredients.setEnabled(false);
        etMethod.setEnabled(false);
        etRegionalName.setEnabled(false);
        spCategory.setEnabled(false);
        btnPickImage.setVisibility(View.GONE);
        btnDelete.setVisibility(View.GONE);
    }

    private void saveRecipe() {
        String title = etTitle.getText().toString().trim();
        String ingredients = etIngredients.getText().toString().trim();
        String method = etMethod.getText().toString().trim();
        String result = etResult.getText().toString().trim();
        String regional = etRegionalName.getText().toString().trim();
        String category = spCategory.getSelectedItem() != null ? spCategory.getSelectedItem().toString() : "";
        String imageString;
        if (selectedImageUri != null) {
            imageString = selectedImageUri.toString();
        } else if (mode.equals("edit") && currentRecipe.getImageUri() != null) {
            imageString = currentRecipe.getImageUri(); // Keep existing image
        } else {
            imageString = "";
        }

        // Verification
        if (!userRole.equals("reviewer")) {
            if (title.isEmpty() || ingredients.isEmpty() || method.isEmpty()) {
                Toast.makeText(this, "Judul, Bahan, dan Metode wajib diisi!", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (mode.equals("add")) {
            Recipe r = new Recipe();
            r.setTitle(title);
            r.setIngredients(ingredients);
            r.setMethod(method);
            r.setResultNote(result);
            r.setRegionalName(regional);
            r.setCategoryName(category);
            r.setImageUri(imageString);
            r.setChefId(userId);

            if (db.addRecipe(r) > 0) {
                Toast.makeText(this, "Resep tersimpan", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Gagal simpan", Toast.LENGTH_SHORT).show();
            }
        } else {
            currentRecipe.setTitle(title);
            currentRecipe.setIngredients(ingredients);
            currentRecipe.setMethod(method);
            currentRecipe.setResultNote(result);
            currentRecipe.setRegionalName(regional);
            currentRecipe.setCategoryName(category);
            currentRecipe.setImageUri(imageString);

            if (db.updateRecipe(currentRecipe)) {
                Toast.makeText(this, "Resep diupdate", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Gagal update", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void deleteRecipe() {
        if (db.deleteRecipe(recipeId)) {
            Toast.makeText(this, "Terhapus", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Gagal hapus", Toast.LENGTH_SHORT).show();
        }
    }
}
