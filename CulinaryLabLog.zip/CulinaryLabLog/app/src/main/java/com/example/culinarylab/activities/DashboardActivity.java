package com.example.culinarylab.activities;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.culinarylab.R;
import com.example.culinarylab.fragments.HomeFragment;
import com.example.culinarylab.fragments.ProfileFragment;
import com.example.culinarylab.fragments.SearchFragment;
import com.example.culinarylab.fragments.VideoFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class DashboardActivity extends AppCompatActivity {

    String username;
    String role;
    int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Get Data
        username = getIntent().getStringExtra("username");
        role = getIntent().getStringExtra("role");
        userId = getIntent().getIntExtra("userId", -1);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                int itemId = item.getItemId();

                // Create bundle with user data for all fragments
                Bundle bundle = new Bundle();
                bundle.putString("username", username);
                bundle.putString("role", role);
                bundle.putInt("userId", userId);

                if (itemId == R.id.nav_home) {
                    selectedFragment = new HomeFragment();
                } else if (itemId == R.id.nav_search) {
                    selectedFragment = new SearchFragment();
                } else if (itemId == R.id.nav_profile) {
                    selectedFragment = new ProfileFragment();
                } else if (itemId == R.id.nav_video) {
                    selectedFragment = new VideoFragment();
                }

                if (selectedFragment != null) {
                    selectedFragment.setArguments(bundle);
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, selectedFragment)
                            .commit();
                }
                return true;
            }
        });

        // Initialize default fragment
        if (savedInstanceState == null) {
            Fragment homeFragment = new HomeFragment();
            Bundle bundle = new Bundle();
            bundle.putString("username", username);
            bundle.putString("role", role);
            bundle.putInt("userId", userId);
            homeFragment.setArguments(bundle);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, homeFragment)
                    .commit();
        }
    }
}
