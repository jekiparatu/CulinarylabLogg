package com.example.culinarylab.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;
import com.example.culinarylab.models.Video;

import java.util.List;

public class AddVideoActivity extends AppCompatActivity {

    EditText etTitle, etDuration, etLink;
    Spinner spCategory;
    Button btnSelectThumbnail, btnSave;
    ImageView imgPreview;

    DBHelper db;
    Uri thumbnailUri;

    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_video);

        db = new DBHelper(this);

        etTitle = findViewById(R.id.etVideoTitle);
        etDuration = findViewById(R.id.etDuration);
        etLink = findViewById(R.id.etVideoLink);
        spCategory = findViewById(R.id.spCategory);
        btnSelectThumbnail = findViewById(R.id.btnSelectThumbnail);
        btnSave = findViewById(R.id.btnSaveVideo);
        imgPreview = findViewById(R.id.imgPreview);

        loadCategories();

        btnSelectThumbnail.setOnClickListener(v -> openFileChooser());

        btnSave.setOnClickListener(v -> saveVideo());
    }

    private void loadCategories() {
        List<String> categories = db.getAllCategories();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(adapter);
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            thumbnailUri = data.getData();
            imgPreview.setImageURI(thumbnailUri);
        }
    }

    private void saveVideo() {
        String title = etTitle.getText().toString().trim();
        String duration = etDuration.getText().toString().trim();
        String link = etLink.getText().toString().trim();
        String category = spCategory.getSelectedItem() != null ? spCategory.getSelectedItem().toString() : "";

        if (title.isEmpty() || duration.isEmpty()) {
            Toast.makeText(this, "Mohon lengkapi semua data", Toast.LENGTH_SHORT).show();
            return;
        }

        Video video = new Video();
        video.setTitle(title);
        video.setDuration(duration);
        video.setCategory(category);
        video.setVideoUrl(link);
        video.setVideoThumbnail(thumbnailUri != null ? thumbnailUri.toString() : null);

        if (db.addVideo(video)) {
            Toast.makeText(this, "Video berhasil ditambahkan", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Gagal menambahkan video", Toast.LENGTH_SHORT).show();
        }
    }
}
