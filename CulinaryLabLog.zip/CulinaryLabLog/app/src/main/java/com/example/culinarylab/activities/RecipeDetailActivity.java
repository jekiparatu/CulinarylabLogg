package com.example.culinarylab.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;
import com.example.culinarylab.models.Recipe;
import com.example.culinarylab.models.Review;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.chip.Chip;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class RecipeDetailActivity extends AppCompatActivity {

    ImageView ivDetailImage;
    TextView tvTitle, tvIngredients, tvMethod, tvChef, tvResult;
    Chip chipCategory, chipRegional;
    RatingBar ratingBarDisplay, ratingBarInput;
    ImageView btnFavorite; // New Favorite Button

    // Inputs (for adding review)
    TextInputEditText etReviewerComment;
    Button btnSaveReview;

    // Actions
    ExtendedFloatingActionButton fabAction; // Edit
    FloatingActionButton fabDelete; // Delete

    // Containers
    MaterialCardView cardReviewer, cardReviewList;
    CollapsingToolbarLayout collapsingToolbar;

    // Reviews List
    RecyclerView rvReviews;
    ReviewAdapter reviewAdapter;
    TextView tvNoReviews;

    DBHelper db;
    int recipeId;
    int userId;
    String userRole;

    Recipe recipe;
    boolean isFavorite = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        db = new DBHelper(this);

        // Bind Views
        collapsingToolbar = findViewById(R.id.collapsingToolbar);
        ivDetailImage = findViewById(R.id.ivDetailImage);

        tvTitle = findViewById(R.id.tvTitle);
        tvIngredients = findViewById(R.id.tvIngredients);
        tvMethod = findViewById(R.id.tvMethod);
        tvChef = findViewById(R.id.tvChef);
        tvResult = findViewById(R.id.tvResultNote);

        chipCategory = findViewById(R.id.chipCategory);
        chipRegional = findViewById(R.id.chipRegional);

        ratingBarDisplay = findViewById(R.id.ratingBarDisplay);
        btnFavorite = findViewById(R.id.btnFavorite); // Need to add ID to XML

        // Reviews List Area
        cardReviewList = findViewById(R.id.cardReviewDisplay); // Reusing existing card ID but will change content logic
        rvReviews = findViewById(R.id.rvReviews); // Need to add to XML
        tvNoReviews = findViewById(R.id.tvNoReviews); // Need to add to XML

        // Reviewer inputs
        cardReviewer = findViewById(R.id.cardReviewer);
        ratingBarInput = findViewById(R.id.ratingBarInput);
        etReviewerComment = findViewById(R.id.etReviewerComment);
        btnSaveReview = findViewById(R.id.btnSaveReview);

        // Actions
        fabAction = findViewById(R.id.fabAction);
        fabDelete = findViewById(R.id.fabDelete);

        // Get Intent Data
        recipeId = getIntent().getIntExtra("recipeId", -1);
        userId = getIntent().getIntExtra("userId", -1);
        userRole = getIntent().getStringExtra("role");

        if (recipeId == -1 || userRole == null) {
            Toast.makeText(this, "Data tidak valid", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        recipe = db.getRecipeById(recipeId);
        if (recipe == null) {
            Toast.makeText(this, "Resep tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadDataToView();
        setupRolePermissions();
        setupReviewsList();
        checkFavoriteStatus();

        // Listeners
        fabAction.setOnClickListener(v -> {
            Intent i = new Intent(this, AddEditRecipeActivity.class);
            i.putExtra("mode", "edit");
            i.putExtra("recipeId", recipeId);
            i.putExtra("userId", userId);
            i.putExtra("role", userRole);
            startActivity(i);
        });

        fabDelete.setOnClickListener(v -> {
            if (db.deleteRecipe(recipeId)) {
                Toast.makeText(this, "Resep berhasil dihapus", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Gagal menghapus resep", Toast.LENGTH_SHORT).show();
            }
        });

        btnSaveReview.setOnClickListener(v -> handleReviewSave());

        btnFavorite.setOnClickListener(v -> toggleFavorite());

        // Chef Click Interaction
        tvChef.setOnClickListener(v -> {
            if (recipe.getChefId() > 0) {
                Intent i = new Intent(this, RecipeListActivity.class);
                i.putExtra("userId", userId); // User viewing
                i.putExtra("role", userRole); // User viewing role
                i.putExtra("chefIdFilter", recipe.getChefId()); // Filter by this chef
                i.putExtra("chefNameFilter", recipe.getChefName()); // For Title
                startActivity(i);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        recipe = db.getRecipeById(recipeId);
        if (recipe != null) {
            loadDataToView();
            loadReviews(); // Refresh reviews
        }
    }

    private void loadDataToView() {
        if (recipe.getImageUri() != null && !recipe.getImageUri().isEmpty()) {
            loadRecipeImage(ivDetailImage, recipe.getImageUri());
        }

        collapsingToolbar.setTitle(recipe.getTitle());
        tvTitle.setText(recipe.getTitle());

        chipCategory.setText(recipe.getCategoryName() != null ? recipe.getCategoryName() : "Umum");
        chipRegional.setText(
                recipe.getRegionalName() != null && !recipe.getRegionalName().isEmpty() ? recipe.getRegionalName()
                        : "Global");

        tvIngredients.setText(recipe.getIngredients());
        tvMethod.setText(recipe.getMethod());

        // Show Chef Name
        String chefDisplay = "Oleh: "
                + (recipe.getChefName() != null ? recipe.getChefName() : "Chef " + recipe.getChefId());
        tvChef.setText(chefDisplay);

        tvResult.setText(recipe.getResultNote());

        ratingBarDisplay.setRating(recipe.getRating());
    }

    private void checkFavoriteStatus() {
        isFavorite = db.isFavorite(userId, recipeId);
        updateFavoriteIcon();
    }

    private void toggleFavorite() {
        isFavorite = !isFavorite;
        db.setFavorite(userId, recipeId, isFavorite);
        updateFavoriteIcon();
        Toast.makeText(this, isFavorite ? "Disimpan ke Favorit" : "Dihapus dari Favorit", Toast.LENGTH_SHORT).show();
    }

    private void updateFavoriteIcon() {
        if (isFavorite) {
            btnFavorite.setImageResource(R.drawable.ic_heart_filled); // Need to ensure exists
            btnFavorite.setColorFilter(getResources().getColor(R.color.love_red));
        } else {
            btnFavorite.setImageResource(R.drawable.ic_heart_outline); // Need to ensure exists
            btnFavorite.setColorFilter(getResources().getColor(android.R.color.darker_gray));
        }
    }

    private void loadRecipeImage(ImageView imageView, String imageUri) {
        if (imageUri == null || imageUri.isEmpty()) {
            imageView.setImageResource(R.drawable.placeholder_recipe);
            return;
        }

        if (!imageUri.contains("/") && !imageUri.contains(":")) {
            int resId = getResources().getIdentifier(imageUri, "drawable", getPackageName());
            if (resId != 0) {
                imageView.setImageResource(resId);
            } else {
                imageView.setImageResource(R.drawable.placeholder_recipe);
            }
        } else {
            try {
                imageView.setImageURI(android.net.Uri.parse(imageUri));
            } catch (Exception e) {
                imageView.setImageResource(R.drawable.placeholder_recipe);
            }
        }
    }

    private void setupRolePermissions() {
        // Everyone can favorite
        btnFavorite.setVisibility(View.VISIBLE);

        switch (userRole) {
            case "reviewer":
                fabAction.setVisibility(View.GONE);
                fabDelete.setVisibility(View.GONE);
                // Reviewer can add review
                cardReviewer.setVisibility(View.VISIBLE);
                break;

            case "chef":
                boolean isOwner = recipe.getChefId() == userId;
                if (isOwner) {
                    fabAction.setVisibility(View.VISIBLE);
                    fabDelete.setVisibility(View.VISIBLE);
                } else {
                    fabAction.setVisibility(View.GONE);
                    fabDelete.setVisibility(View.GONE);
                }
                // Chefs can also review other recipes? Let's say yes for now, or hide it.
                // Assuming Chefs don't review for now to keep it simple, or maybe they do?
                // Let's hide review input for chefs strictly per prompt "Reviewers review".
                cardReviewer.setVisibility(View.GONE);
                break;

            case "admin": // Admin
                cardReviewer.setVisibility(View.GONE);
                fabAction.setVisibility(View.VISIBLE);
                fabDelete.setVisibility(View.VISIBLE);
                break;

            default: // Guest
                cardReviewer.setVisibility(View.GONE);
                fabAction.setVisibility(View.GONE);
                fabDelete.setVisibility(View.GONE);
                break;
        }
    }

    private void setupReviewsList() {
        rvReviews.setLayoutManager(new LinearLayoutManager(this));
        // We need a simple adapter for reviews. Define inline or separate? Inline is
        // easier for now.
        // But need a class. Let's make a simple inner class adapter.
    }

    private void loadReviews() {
        List<Review> reviews = db.getReviewsByRecipe(recipeId);

        if (reviews.isEmpty()) {
            tvNoReviews.setVisibility(View.VISIBLE);
            rvReviews.setVisibility(View.GONE);
        } else {
            tvNoReviews.setVisibility(View.GONE);
            rvReviews.setVisibility(View.VISIBLE);

            reviewAdapter = new ReviewAdapter(reviews);
            rvReviews.setAdapter(reviewAdapter);
        }
    }

    private void handleReviewSave() {
        int rating = (int) ratingBarInput.getRating();
        String comment = etReviewerComment.getText().toString().trim();

        if (rating == 0) {
            Toast.makeText(this, "Mohon berikan rating bintang terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        Review newReview = new Review(recipeId, userId, "Reviewer", rating, comment);
        // Date could be added

        if (db.addReview(newReview)) {
            Toast.makeText(this, "Review berhasil dikirim!", Toast.LENGTH_SHORT).show();
            // Clear inputs
            etReviewerComment.setText("");
            ratingBarInput.setRating(0);

            // Refresh list
            loadReviews();

            // Optionally update recipe average rating here or in DB
        } else {
            Toast.makeText(this, "Gagal mengirim review", Toast.LENGTH_SHORT).show();
        }
    }

    // --- Simple Review Adapter ---
    class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.Holder> {
        List<Review> list;

        public ReviewAdapter(List<Review> list) {
            this.list = list;
        }

        @androidx.annotation.NonNull
        @Override
        public Holder onCreateViewHolder(@androidx.annotation.NonNull android.view.ViewGroup parent, int viewType) {
            View v = getLayoutInflater().inflate(R.layout.item_review, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@androidx.annotation.NonNull Holder holder, int position) {
            Review r = list.get(position);
            holder.tvName.setText(r.getReviewerName() != null ? r.getReviewerName() : "User " + r.getUserId());
            holder.tvComment.setText(r.getComment());
            holder.ratingBar.setRating(r.getRating());
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class Holder extends RecyclerView.ViewHolder {
            TextView tvName, tvComment;
            RatingBar ratingBar;

            Holder(View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvReviewerName);
                tvComment = itemView.findViewById(R.id.tvReviewComment);
                ratingBar = itemView.findViewById(R.id.rbReviewRating);
            }
        }
    }
}
