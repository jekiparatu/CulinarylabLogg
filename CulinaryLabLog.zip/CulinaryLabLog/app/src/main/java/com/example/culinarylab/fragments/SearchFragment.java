package com.example.culinarylab.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;
import com.example.culinarylab.activities.RecipeDetailActivity;
import com.example.culinarylab.models.Recipe;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SearchFragment extends Fragment {

    EditText etSearch;
    RecyclerView rvFilters, rvRecent, rvRecommendations, rvResults;
    ScrollView containerIdle;

    DBHelper db;
    List<Recipe> allRecipes;

    // User data
    String username;
    String role;
    int userId;

    // Adapters
    ResultAdapter resultAdapter;
    List<Recipe> resultList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        db = new DBHelper(getActivity());

        etSearch = view.findViewById(R.id.etSearchBox);
        rvFilters = view.findViewById(R.id.rvFilters);
        rvRecent = view.findViewById(R.id.rvRecentSearches);
        rvRecommendations = view.findViewById(R.id.rvSearchRecommendations);
        rvResults = view.findViewById(R.id.rvSearchResults);
        containerIdle = view.findViewById(R.id.containerIdle);

        // Get user data from Arguments
        if (getArguments() != null) {
            username = getArguments().getString("username");
            role = getArguments().getString("role");
            userId = getArguments().getInt("userId", -1);
        }

        setupFilters();
        setupRecent();
        setupRecommendations();
        setupResults(); // Prepares the adapter

        setupSearchListener();

        return view;
    }

    private void setupSearchListener() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = s.toString().trim();
                if (text.isEmpty()) {
                    showIdleState();
                } else {
                    performSearch(text);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void showIdleState() {
        containerIdle.setVisibility(View.VISIBLE);
        rvResults.setVisibility(View.GONE);
    }

    private void performSearch(String query) {
        containerIdle.setVisibility(View.GONE);
        rvResults.setVisibility(View.VISIBLE);

        List<Recipe> filtered = new ArrayList<>();
        if (allRecipes == null)
            allRecipes = db.getAllRecipes(); // Lazy load

        for (Recipe r : allRecipes) {
            String q = query.toLowerCase();
            if (r.getTitle().toLowerCase().contains(q) ||
                    (r.getIngredients() != null && r.getIngredients().toLowerCase().contains(q)) ||
                    (r.getCategoryName() != null && r.getCategoryName().toLowerCase().contains(q))) {
                filtered.add(r);
            }
        }

        resultAdapter.updateList(filtered);
    }

    // --- SETUP HELPERS ---

    private void setupFilters() {
        List<String> filters = Arrays.asList("Makanan Utama", "Dessert", "Nusantara", "Healthy", "Pasta");
        FilterAdapter adapter = new FilterAdapter(filters, filter -> {
            etSearch.setText(filter);
            etSearch.setSelection(filter.length());
        });
        rvFilters.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        rvFilters.setAdapter(adapter);
    }

    private void setupRecent() {
        // Static for now
        List<String> recent = Arrays.asList("Ayam rica-rica", "Nasi goreng", "Brownies");
        RecentAdapter adapter = new RecentAdapter(recent, text -> {
            etSearch.setText(text);
            etSearch.setSelection(text.length());
        });
        rvRecent.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvRecent.setAdapter(adapter);
    }

    private void setupRecommendations() {
        allRecipes = db.getAllRecipes();
        List<Recipe> limited = new ArrayList<>();
        if (allRecipes != null && !allRecipes.isEmpty()) {
            // Take random or last few
            int size = Math.min(allRecipes.size(), 3);
            for (int i = 0; i < size; i++)
                limited.add(allRecipes.get(i));
        }

        // Reuse ResultAdapter layout for recommendations effectively?
        // Actually let's use ResultAdapter for consistency, vertical list.
        ResultAdapter adapter = new ResultAdapter(getContext(), limited);
        rvRecommendations.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvRecommendations.setAdapter(adapter);
    }

    private void setupResults() {
        resultList = new ArrayList<>();
        resultAdapter = new ResultAdapter(getContext(), resultList);
        rvResults.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvResults.setAdapter(resultAdapter);
    }

    /**
     * Helper method to load recipe images from either drawable resource names or
     * file URIs
     */
    private void loadRecipeImage(ImageView imageView, String imageUri) {
        if (imageUri == null || imageUri.isEmpty()) {
            imageView.setImageResource(R.drawable.placeholder_recipe);
            return;
        }

        // Check if it's a drawable resource name (no slashes or colons)
        if (!imageUri.contains("/") && !imageUri.contains(":")) {
            // It's a drawable resource name like "img_jagung_bose"
            int resId = getResources().getIdentifier(imageUri, "drawable", getActivity().getPackageName());
            if (resId != 0) {
                imageView.setImageResource(resId);
            } else {
                imageView.setImageResource(R.drawable.placeholder_recipe);
            }
        } else {
            // It's a file URI
            try {
                imageView.setImageURI(Uri.parse(imageUri));
            } catch (Exception e) {
                imageView.setImageResource(R.drawable.placeholder_recipe);
            }
        }
    }

    // --- ADAPTERS ---

    // 1. Filter Adapter
    class FilterAdapter extends RecyclerView.Adapter<FilterAdapter.Holder> {
        List<String> list;
        OnItemClick listener;

        public FilterAdapter(List<String> list, OnItemClick listener) {
            this.list = list;
            this.listener = listener;
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.item_search_filter, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            String s = list.get(position);
            holder.tv.setText(s);
            holder.itemView.setOnClickListener(v -> listener.onClick(s));
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class Holder extends RecyclerView.ViewHolder {
            TextView tv;

            Holder(View v) {
                super(v);
                tv = v.findViewById(R.id.tvFilterName);
            }
        }
    }

    // 2. Recent Adapter
    class RecentAdapter extends RecyclerView.Adapter<RecentAdapter.Holder> {
        List<String> list;
        OnItemClick listener;

        public RecentAdapter(List<String> list, OnItemClick listener) {
            this.list = list;
            this.listener = listener;
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(
                    LayoutInflater.from(getContext()).inflate(R.layout.item_search_suggestion, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            String s = list.get(position);
            holder.tv.setText(s);
            holder.itemView.setOnClickListener(v -> listener.onClick(s));
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class Holder extends RecyclerView.ViewHolder {
            TextView tv;

            Holder(View v) {
                super(v);
                tv = v.findViewById(R.id.tvHistoryItem);
            }
        }
    }

    // 3. Result Adapter (Used for Results AND Recommendations)
    class ResultAdapter extends RecyclerView.Adapter<ResultAdapter.Holder> {
        List<Recipe> list;
        Context context;

        public ResultAdapter(Context c, List<Recipe> l) {
            this.context = c;
            this.list = new ArrayList<>(l);
        }

        public void updateList(List<Recipe> l) {
            list.clear();
            list.addAll(l);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(context).inflate(R.layout.item_search_result, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            Recipe r = list.get(position);
            holder.tvTitle.setText(r.getTitle());
            holder.tvDesc.setText(r.getIngredients());
            holder.tvRating.setText(r.getRating() + " ★");

            String cat = r.getCategoryName();
            if (cat == null || cat.isEmpty())
                cat = "Recipe";
            holder.tvCategory.setText(cat);

            if (r.getImageUri() != null)
                loadRecipeImage(holder.img, r.getImageUri());
            else
                holder.img.setImageResource(R.drawable.ic_launcher_background);

            holder.itemView.setOnClickListener(v -> {
                Intent i = new Intent(context, RecipeDetailActivity.class);
                i.putExtra("recipeId", r.getId());
                i.putExtra("userId", userId);
                i.putExtra("role", role);
                context.startActivity(i);
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class Holder extends RecyclerView.ViewHolder {
            TextView tvTitle, tvDesc, tvCategory, tvRating;
            ImageView img;

            Holder(View v) {
                super(v);
                tvTitle = v.findViewById(R.id.tvResultTitle);
                tvDesc = v.findViewById(R.id.tvResultDesc);
                tvCategory = v.findViewById(R.id.tvResultCategory);
                tvRating = v.findViewById(R.id.tvResultRating);
                img = v.findViewById(R.id.imgResult);
            }
        }
    }

    interface OnItemClick {
        void onClick(String text);
    }
}
