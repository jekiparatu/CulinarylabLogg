package com.example.culinarylab.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.R;
import com.example.culinarylab.models.User;

public class EditProfileActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    ImageView ivProfilePhoto;
    EditText etName, etEmail;
    Button btnSelectPhoto, btnSave, btnCancel;

    DBHelper db;
    int userId;
    Uri selectedPhotoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        db = new DBHelper(this);

        // Get user ID from intent
        userId = getIntent().getIntExtra("userId", -1);
        if (userId == -1) {
            Toast.makeText(this, "Error: User ID tidak valid", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Bind views
        ivProfilePhoto = findViewById(R.id.ivProfilePhoto);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        btnSelectPhoto = findViewById(R.id.btnSelectPhoto);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        // Load current user data
        loadUserData();

        // Set listeners
        btnSelectPhoto.setOnClickListener(v -> selectPhoto());
        ivProfilePhoto.setOnClickListener(v -> selectPhoto()); // Also click image to select
        btnSave.setOnClickListener(v -> saveProfile());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void loadUserData() {
        User user = db.getUserById(userId);
        if (user != null) {
            etName.setText(user.getName());
            etEmail.setText(user.getEmail() != null ? user.getEmail() : "");

            if (user.getPhotoUri() != null && !user.getPhotoUri().isEmpty()) {
                ivProfilePhoto.setImageURI(Uri.parse(user.getPhotoUri()));
            }
        }
    }

    private void selectPhoto() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            selectedPhotoUri = data.getData();
            ivProfilePhoto.setImageURI(selectedPhotoUri);

            // Persist permission
            try {
                getContentResolver().takePersistableUriPermission(selectedPhotoUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void saveProfile() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        String photoUri = selectedPhotoUri != null ? selectedPhotoUri.toString() : null;

        if (db.updateUserProfile(userId, name, email, photoUri)) {
            Toast.makeText(this, "Profile berhasil diupdate", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Gagal update profile", Toast.LENGTH_SHORT).show();
        }
    }
}
