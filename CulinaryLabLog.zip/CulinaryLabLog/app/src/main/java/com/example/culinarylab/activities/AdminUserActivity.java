package com.example.culinarylab.activities;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.BaseAdapter;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.culinarylab.DBHelper;
import com.example.culinarylab.models.User;
import com.example.culinarylab.R;

import java.util.ArrayList;
import java.util.List;

public class AdminUserActivity extends AppCompatActivity {

    ListView lvUsers;
    View btnAddUser; // Can be FloatingActionButton or Button
    DBHelper db;
    UserAdapter adapter;
    List<User> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_user);

        db = new DBHelper(this);
        lvUsers = findViewById(R.id.lvUsers);
        btnAddUser = findViewById(R.id.btnAddUser);

        loadUsers();

        btnAddUser.setOnClickListener(v -> showAddUserDialog());

        lvUsers.setOnItemClickListener((parent, view, position, id) -> {
            User u = userList.get(position);
            if (u.getRole().equals("admin")) {
                Toast.makeText(this, "Cannot delete admin", Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Delete User")
                    .setMessage("Delete user " + u.getName() + " (" + u.getRole() + ")?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        if (db.deleteUser(u.getId())) {
                            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                            loadUsers();
                        } else {
                            Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    private void loadUsers() {
        userList = db.getAllUsers();
        adapter = new UserAdapter(this, userList);
        lvUsers.setAdapter(adapter);
    }

    private void showAddUserDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New User");

        // Simpler approach: Create a LinearLayout Programmatically
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText etUser = new EditText(this);
        etUser.setHint("Username");
        layout.addView(etUser);

        final EditText etPass = new EditText(this);
        etPass.setHint("Password");
        layout.addView(etPass);

        final Spinner spRole = new Spinner(this);
        String[] roles = { "chef", "reviewer", "admin" };
        ArrayAdapter<String> roleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, roles);
        roleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spRole.setAdapter(roleAdapter);
        layout.addView(spRole);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String user = etUser.getText().toString().trim();
            String pass = etPass.getText().toString().trim();
            String role = spRole.getSelectedItem().toString();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.registerUser(user, pass, role)) {
                Toast.makeText(this, "User Created", Toast.LENGTH_SHORT).show();
                loadUsers();
            } else {
                Toast.makeText(this, "Failed (Username exists?)", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // Custom Adapter
    class UserAdapter extends BaseAdapter {
        Context context;
        List<User> list;

        public UserAdapter(Context context, List<User> list) {
            this.context = context;
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return list.get(position).getId();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.item_admin_user, parent, false);
            }

            User u = list.get(position);

            TextView tvName = convertView.findViewById(R.id.tvUserName);
            TextView tvRole = convertView.findViewById(R.id.tvUserRole);
            ImageView ivIcon = convertView.findViewById(R.id.ivUserIcon);

            tvName.setText(u.getName());
            tvRole.setText(u.getRole());

            // Optional: Change icon based on role
            if ("admin".equalsIgnoreCase(u.getRole())) {
                ivIcon.setColorFilter(0xFFD32F2F); // Red tint for admin
            } else if ("chef".equalsIgnoreCase(u.getRole())) {
                ivIcon.setColorFilter(0xFF009688); // Teal for chef
            } else {
                ivIcon.setColorFilter(0xFF546E7A); // Gray for others
            }

            return convertView;
        }
    }
}
